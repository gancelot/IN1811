from plugin import Plugin


class Plugin1(Plugin):
    def execute(self):
        print('do stuff within Plugin1')
