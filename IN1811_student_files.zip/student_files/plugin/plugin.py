from abc import ABC, abstractmethod


class Plugin(ABC):
    @abstractmethod
    def execute(self):
        raise NotImplementedError('Must provide an execute() method')
