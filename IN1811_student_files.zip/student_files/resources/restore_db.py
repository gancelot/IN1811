"""

    Run this to restore the database, if needed.

"""
import csv
from pathlib import Path
import sqlite3
import sys

resources = [
    {
        'data_file': 'celebrity_100.csv',
        'drop_stmt': 'DROP TABLE IF EXISTS celebrity',
        'create_stmt': 'CREATE TABLE IF NOT EXISTS celebrity (id integer primary key autoincrement, Name VARCHAR(100), Pay REAl, Year VARCHAR(15), Category VARCHAR(50))',
        'insert_stmt': 'INSERT INTO celebrity(Name, Pay, Year, Category) VALUES (?,?,?,?)',
        'columns_to_insert': 4
    },
    {
        'data_file': 'customer_purchases.csv',
        'drop_stmt': 'DROP TABLE IF EXISTS purchases',
        'create_stmt': 'CREATE TABLE purchases (id integer primary key autoincrement, InvoiceNo VARCHAR(30) NOT NULL, StockCode VARCHAR(30) NOT NULL, Quantity INTEGER NOT NULL, Description VARCHAR(150), InvoiceDate VARCHAR(50), UnitPrice REAL, CustomerID VARCHAR(50), Country VARCHAR(50))',
        'insert_stmt': 'INSERT INTO purchases(InvoiceNo, StockCode, Description, Quantity, InvoiceDate, UnitPrice, CustomerID, Country) VALUES (?,?,?,?,?,?,?,?)',
        'columns_to_insert': 8,
        'encoding': 'unicode_escape'
    },
    {
        'data_file': 'netflix_titles.csv',
        'drop_stmt': 'DROP TABLE IF EXISTS netflix_titles',
        'create_stmt': 'CREATE TABLE IF NOT EXISTS netflix_titles (show_id VARCHAR(10) NOT NULL PRIMARY KEY, type VARCHAR(20), title VARCHAR(60), director VARCHAR(50), cast VARCHAR(250), country VARCHAR(40), date_added VARCHAR(40), release_year VARCHAR(10), rating VARCHAR(10), duration VARCHAR(20), listed_in VARCHAR(250), description VARCHAR(500))',
        'insert_stmt': 'INSERT INTO netflix_titles(show_id, type, title, director, cast, country, date_added, release_year, rating, duration, listed_in, description) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
        'columns_to_insert': 12
    },
    {
        'data_file': 'richest_athletes.csv',
        'drop_stmt': 'DROP TABLE IF EXISTS athletes',
        'create_stmt': 'CREATE TABLE IF NOT EXISTS athletes (SNo VARCHAR(10) NOT NULL PRIMARY KEY, Name VARCHAR(60), Nationality VARCHAR(25), CurrentRank VARCHAR(10), PreviousYearRank VARCHAR(20), Sport VARCHAR(50), Year VARCHAR(15), Earnings REAL)',
        'insert_stmt': 'INSERT INTO athletes(SNo, Name, Nationality, CurrentRank, PreviousYearRank, Sport, Year, Earnings) VALUES (?,?,?,?,?,?,?,?)',
        'columns_to_insert': 8
    },
    {
        'data_file': 'users.csv',
        'drop_stmt': 'DROP TABLE IF EXISTS users',
        'create_stmt': 'CREATE TABLE IF NOT EXISTS users (id INTEGER NOT NULL PRIMARY KEY autoincrement, name VARCHAR(80) NOT NULL, username VARCHAR(80) NOT NULL, email VARCHAR(120) NOT NULL UNIQUE, password VARCHAR(250) NOT NULL)',
        'insert_stmt': 'INSERT INTO users(id,name,username,email,password) VALUES (?,?,?,?,?)',
        'columns_to_insert': 5
    },
    {
        'data_file': 'user_auth.csv',
        'drop_stmt': 'DROP TABLE IF EXISTS user_auth',
        'create_stmt': 'CREATE TABLE IF NOT EXISTS user_auth (id integer not null primary key autoincrement, public_id varchar, name varchar, password varchar, admin boolean)',
        'insert_stmt': 'INSERT INTO user_auth(id, public_id, name, password, admin) VALUES (?,?,?,?,?)',
        'columns_to_insert': 5
    },
    {
        'data_file': 'england_premier_league_teams_2018.csv',
        'drop_stmt': 'DROP TABLE IF EXISTS teams',
        'create_stmt': 'CREATE TABLE IF NOT EXISTS teams (id integer not null primary key autoincrement, team_name,common_name,season,country,matches_played,matches_played_home,matches_played_away,suspended_matches,wins,wins_home,wins_away,draws,draws_home,draws_away,losses,losses_home,losses_away,points_per_game,points_per_game_home,points_per_game_away,league_position)',
        'insert_stmt': 'INSERT INTO teams(id, team_name, common_name, season, country, matches_played, matches_played_home, matches_played_away, suspended_matches, wins, wins_home, wins_away, draws, draws_home, draws_away, losses, losses_home, losses_away, points_per_game, points_per_game_home, points_per_game_away, league_position) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
        'columns_to_insert': 22
    },
    {
        'data_file': 'england_premier_league_2018.csv',
        'drop_stmt': 'DROP TABLE IF EXISTS players',
        'create_stmt': 'CREATE TABLE IF NOT EXISTS players (id integer not null primary key autoincrement, '
                       'full_name varchar, age integer, birthday varchar, birthday_GMT varchar, league varchar, '
                       'season varchar, position varchar, team_id integer, '
                       'current_club varchar, minutes_played_overall integer, '
                       'minutes_played_home integer, minutes_played_away integer, nationality varchar, '
                       'appearances_overall integer, appearances_home integer, appearances_away integer, '
                       'goals_overall integer, goals_home integer, goals_away integer, assists_overall integer, '
                       'assists_home integer,assists_away integer, penalty_goals integer,penalty_misses integer, '
                       'clean_sheets_overall varchar, clean_sheets_home varchar, clean_sheets_away varchar, '
                       'conceded_overall varchar, conceded_home varchar, conceded_away varchar, '
                       'yellow_cards_overall integer, red_cards_overall integer, '
                       'goals_involved_per_90_overall integer, assists_per_90_overall integer, '
                       'goals_per_90_overall integer, goals_per_90_home integer, goals_per_90_away integer, '
                       'min_per_goal_overall integer, conceded_per_90_overall integer, min_per_conceded_overall integer, '
                       'min_per_match integer, min_per_card_overall integer, min_per_assist_overall integer, '
                       'cards_per_90_overall integer, rank_in_league_top_attackers integer, '
                       'rank_in_league_top_midfielders integer, rank_in_league_top_defenders integer, '
                       'rank_in_club_top_scorer integer, FOREIGN KEY (team_id) REFERENCES teams(id))',
        'insert_stmt': 'INSERT INTO players(full_name, age, birthday, birthday_GMT, league, season, position, team_id,'
                       'current_club, minutes_played_overall, minutes_played_home, minutes_played_away, nationality, '
                       'appearances_overall, appearances_home, appearances_away, goals_overall, goals_home, goals_away, '
                       'assists_overall, assists_home, assists_away, penalty_goals, penalty_misses, clean_sheets_overall, '
                       'clean_sheets_home, clean_sheets_away, conceded_overall, conceded_home, conceded_away, '
                       'yellow_cards_overall, red_cards_overall, goals_involved_per_90_overall, assists_per_90_overall, '
                       'goals_per_90_overall, goals_per_90_home, goals_per_90_away, min_per_goal_overall, '
                       'conceded_per_90_overall, min_per_conceded_overall, min_per_match, min_per_card_overall, '
                       'min_per_assist_overall, cards_per_90_overall, rank_in_league_top_attackers, '
                       'rank_in_league_top_midfielders, rank_in_league_top_defenders, rank_in_club_top_scorer) '
                       'VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
        'columns_to_insert': 48
    }
]


def create_db_table(resource: dict, has_header: bool = True, encoding='utf-8-sig'):
    db_file = 'course_data.db'

    data_filename = resource.get('data_file')
    drop_stmt = resource.get('drop_stmt')
    create_stmt = resource.get('create_stmt')
    insert_stmt = resource.get('insert_stmt')
    columns_to_insert = resource.get('columns_to_insert')
    file_encoding = resource.get('encoding')
    if file_encoding:
        encoding = file_encoding

    if not all([data_filename, drop_stmt, create_stmt, insert_stmt, columns_to_insert]):
        print(f'\n{data_filename} does not contain a file name (data_file), a drop statement (drop_stmt), a create statement (create_stmt), and an insert statement (insert_stmt), and a number of columns to insert (columns_to_insert).\n\n')
        return

    data_filename = Path(data_filename)
    data = []

    try:
        with open(data_filename, mode='rt', encoding=encoding) as f:
            print(f'\nReading data file: {data_filename}')
            try:
                reader = csv.reader(f)
                for row in reader:
                    data.append(row)
            except (UnicodeDecodeError, csv.Error) as err:
                print(f'Data reading error: {err}.  Problem occurred on line: {reader.line_num}.')
    except IOError as err:
        print(f'IOError: {err}')
        return

    print(f'File read complete: {data_filename}')
    if has_header:
        data = data[1:]

    connection = None
    try:
        print(f'Database {db_file} opened')
        connection = sqlite3.connect(db_file)
        cursor = connection.cursor()
        cursor.execute(drop_stmt)
        print('--> Table dropped')
        cursor.execute(create_stmt)
        print('--> New table created')
        for row in data:
            cursor.execute(insert_stmt, row[:columns_to_insert])
        print('--> Data Inserted')
        connection.commit()
        print(data_filename.stem, f'data loaded into {db_file}')
    except Exception as err:
        if connection:
            connection.rollback()
        print('Warning: ', data_filename.stem, f'data NOT loaded into {db_file}')
        print(f'Database Error (Type: {type(err)}): {err}', file=sys.stderr)
    finally:
        if connection:
            connection.close()
            print(f'Database {db_file} closed')


for resource in resources:
    create_db_table(resource)
