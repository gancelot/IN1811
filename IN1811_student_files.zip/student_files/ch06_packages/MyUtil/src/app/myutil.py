def say_hello(name):
    return 'Hello, {name}'.format(name=name)