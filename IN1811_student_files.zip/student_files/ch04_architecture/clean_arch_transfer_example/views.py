"""
    This version of a "clean architecture" uses an Account Transfer use case.  To run it,
    run the views.py file first (which starts a Flask server).

    Then run the client.py file next.

    Clean architecture is not a part of our discussions, but presented here just to give
    a feel for what it looks like in Python.
"""
import logging

from flask import Flask, jsonify, request, Response

from adapters import TransferAdapter, TransferInfo
from repository import TransferStoreImpl

logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)


@app.route('/api/transfer', methods=['POST'])
def make_transfer():
    transfer_adapter = TransferAdapter(TransferStoreImpl())
    status = 200
    try:
        from_acct = request.form.get('from_acct')
        to_acct = request.form.get('to_acct')
        amount = float(request.form.get('amount'))

        post_transfer = transfer_adapter.create(TransferInfo(from_acct, to_acct, amount))
        resp = jsonify(from_acct=post_transfer.src_acct_num, to_acct=post_transfer.dest_acct_num,
                       amount=post_transfer.amount)
    except Exception as err:
        resp = jsonify(data=err)
        status = 404

    return Response(resp.data, mimetype='application/json', status=status)


app.run(host='localhost', port=8051)
