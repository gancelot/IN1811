"""
    This version of a "clean architecture" uses an Account Transfer use case.  To run it,
    run the views.py file first (which starts a Flask server).

    Then run the client.py file next.

    Clean architecture is not a part of our discussions, but presented here just to give
    a feel for what it looks like in Python.
"""
import requests

print(requests.post('http://localhost:8051/api/transfer', data={'from_acct': '101000',
                                                                'to_acct': '121134',
                                                                'amount': 200.00}).text)

print(requests.post('http://localhost:8051/api/transfer', data={'from_acct': '101000',
                                                                'to_acct': '121134',
                                                                'amount': 1200.00}).text)
