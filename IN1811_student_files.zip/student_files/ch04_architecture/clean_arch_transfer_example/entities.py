from datetime import datetime


# entities
class Account:
    def __init__(self, name, balance):
        self.name = name
        self.balance = balance

    def has_funds(self, amount) -> bool:
        return self.balance >= amount

    def debit(self, amount: float) -> float:
        if not self.has_funds(amount):
            raise Exception('Insufficient funds.')  # can make a custom exception
        self.balance -= amount
        return self.balance

    def credit(self, amount: float) -> float:
        self.balance += amount
        return self.balance


class Transfer:
    def __init__(self, src_acct: Account, dest_acct: Account, amount: float):
        self.src_acct = src_acct
        self.dest_acct = dest_acct
        self.amount = amount
        self.transaction_date = datetime.now()
