from abc import ABC, abstractmethod
import logging

from entities import Transfer

logging.basicConfig(level=logging.DEBUG)


# gateway
class Store(ABC):
    @abstractmethod
    def update(self, transfer: Transfer) -> Transfer:
        raise NotImplementedError()


# Implementation
class TransferStoreImpl(Store):
    def __init__(self):
        pass  # connect to db

    def update(self, transfer: Transfer) -> Transfer:
        logging.info('Performing update db operation...')
        return transfer
