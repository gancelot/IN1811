from entities import Transfer
import logging

logging.basicConfig(level=logging.DEBUG)


class TransferUseCase:
    def __init__(self, repository):
        self.repository = repository

    def perform_transfer(self, transfer: Transfer):
        try:
            transfer.src_acct.debit(transfer.amount)
            transfer.dest_acct.credit(transfer.amount)
            transfer = self.repository.update(transfer)
            logging.info('Transfer performed')
        except Exception:
            logging.error('Transfer exception occurred.')

        return transfer
