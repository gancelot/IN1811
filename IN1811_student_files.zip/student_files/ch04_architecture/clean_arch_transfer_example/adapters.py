from dataclasses import dataclass
import logging

from entities import Account, Transfer
from usecases import TransferUseCase
from repository import Store

logging.basicConfig(level=logging.DEBUG)


# adapters
@dataclass
class TransferInfo:
    src_acct_num: str
    dest_acct_num: str
    amount: float


class TransferAdapter:
    def __init__(self, store: Store):
        self.use_case = TransferUseCase(store)

    def create(self, transfer_data: TransferInfo):                          # converts view layer data formats to entity
                                                                            # layer objects used by the use case
        transfer = Transfer(Account(transfer_data.src_acct_num, 1000.00),   # normally we'd get this balance from db
                            Account(transfer_data.dest_acct_num, 1000.00),
                            transfer_data.amount)
        logging.info('Transfer created')
        transfer = self.use_case.perform_transfer(transfer)
        return TransferInfo(transfer.src_acct.name, transfer.dest_acct.name, transfer.amount)
