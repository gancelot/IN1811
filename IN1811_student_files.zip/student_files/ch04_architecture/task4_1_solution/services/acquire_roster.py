from typing import List

from ch04_architecture.task4_1_solution.services.repository.base_store import StoreException
from ch04_architecture.task4_1_solution.services.repository.team_store import TeamStore
from ch04_architecture.task4_1_solution.services.repository.player_store import PlayerStore


# our unit of work
def acquire_roster(team_name: str) -> List:
    try:
        ts = TeamStore()
        team_id = ts.find_by_name(team_name)

        ps = PlayerStore()
        players = ps.find_by_team(team_id)

        return players
    except StoreException as err:
        raise err