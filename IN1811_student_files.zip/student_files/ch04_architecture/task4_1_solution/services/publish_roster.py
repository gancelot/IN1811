from ch04_architecture.task4_1_solution.services.repository.base_store import StoreException

from ch04_architecture.task4_1_solution.services.acquire_roster import acquire_roster


def publish(team_name: str):
    try:
        players = acquire_roster(team_name)
        return players
    except StoreException as err:
        raise err
