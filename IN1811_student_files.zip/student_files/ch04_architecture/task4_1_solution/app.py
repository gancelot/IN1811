"""

    app.py
    This implements a Flask service layer for retrieval of the Team Roster.
    Test by using: http://localhost:8051/api/team_roster/Arsenal

"""
from flask import Flask, jsonify, Response

from services.publish_roster import publish

app = Flask(__name__)


@app.route('/api/team_roster/<name>', methods=['GET'])
def get_roster(name):
    status = 200
    try:
        team = publish(name)
        resp = jsonify(team=team, name=name)
    except Exception as err:
        resp = jsonify(team=[], name=err.args[0])
        status = 404

    return Response(resp.data, mimetype='application/json', status=status)


app.run(host='localhost', port=8051)
