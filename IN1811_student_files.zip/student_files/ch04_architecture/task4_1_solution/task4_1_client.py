import requests

base_url = 'http://localhost:8051'
path = '/api/team_roster/'
team_name = 'Arsenal'

print('Get roster:')
r = requests.get(f'{base_url}{path}{team_name}')
results = r.json()
print(f'URL: {r.url}')
print(results)

team_name = 'Liverpool'
print('Get roster:')
r = requests.get(f'{base_url}{path}{team_name}')
results = r.json()
print(f'URL: {r.url}')
print(results)

team_name = 'foo'
print('Get roster:')
r = requests.get(f'{base_url}{path}{team_name}')
results = r.json()
print(f'URL: {r.url}')
print(results)
