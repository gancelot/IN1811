
"""
    This single file version of a "clean architecture" is the same as the
    clean_arch_transfer_example except it is presented in one file for ease of
    readability.  It uses an Account Transfer use case.  To run it,
    run the clean_arch.py file first (which starts a Flask server).

    Then run the client.py file next.

    Clean architecture is not a part of our discussions, but presented here just to give
    a feel for what it looks like in Python.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
import logging

from flask import Flask, jsonify, request, Response

logging.basicConfig(level=logging.DEBUG)


# entities
class Account:
    def __init__(self, name, balance):
        self.name = name
        self.balance = balance

    def has_funds(self, amount) -> bool:
        return self.balance >= amount

    def debit(self, amount: float) -> float:
        if not self.has_funds(amount):
            raise Exception('Insufficient funds.')  # can make a custom exception
        self.balance -= amount
        return self.balance

    def credit(self, amount: float) -> float:
        self.balance += amount
        return self.balance


class Transfer:
    def __init__(self, src_acct: Account, dest_acct: Account, amount: float):
        self.src_acct = src_acct
        self.dest_acct = dest_acct
        self.amount = amount
        self.transaction_date = datetime.now()


# use cases
class TransferUseCase:
    def __init__(self, repository):
        self.repository = repository

    def perform_transfer(self, transfer: Transfer):
        try:
            transfer.src_acct.debit(transfer.amount)
            transfer.dest_acct.credit(transfer.amount)
            transfer = self.repository.update(transfer)
            logging.info('Transfer performed')
        except Exception:
            logging.error('Transfer exception occurred.')

        return transfer


# gateway
class Store(ABC):
    @abstractmethod
    def update(self, transfer: Transfer) -> Transfer:
        raise NotImplementedError()


# Implementation
class TransferStoreImpl(Store):
    def __init__(self):
        pass  # connect to db

    def update(self, transfer: Transfer) -> Transfer:
        logging.info('Performing update db operation...')
        return transfer


# adapters
@dataclass
class TransferInfo:
    src_acct_num: str
    dest_acct_num: str
    amount: float


class TransferAdapter:
    def __init__(self, store: Store):
        self.use_case = TransferUseCase(store)

    def create(self, transfer_data: TransferInfo):                          # converts view layer data formats to entity
                                                                            # layer objects used by the use case
        transfer = Transfer(Account(transfer_data.src_acct_num, 1000.00),   # normally we'd get this balance from db
                            Account(transfer_data.dest_acct_num, 1000.00),
                            transfer_data.amount)
        logging.info('Transfer created')
        transfer = self.use_case.perform_transfer(transfer)
        return TransferInfo(transfer.src_acct.name, transfer.dest_acct.name, transfer.amount)


# views
app = Flask(__name__)


@app.route('/api/transfer', methods=['POST'])
def make_transfer():
    transfer_adapter = TransferAdapter(TransferStoreImpl())
    status = 200
    try:
        from_acct = request.form.get('from_acct')
        to_acct = request.form.get('to_acct')
        amount = float(request.form.get('amount'))

        post_transfer = transfer_adapter.create(TransferInfo(from_acct, to_acct, amount))
        resp = jsonify(from_acct=post_transfer.src_acct_num, to_acct=post_transfer.dest_acct_num,
                       amount=post_transfer.amount)
    except Exception as err:
        resp = jsonify(data=err)
        status = 404

    return Response(resp.data, mimetype='application/json', status=status)


app.run(host='localhost', port=8051)
