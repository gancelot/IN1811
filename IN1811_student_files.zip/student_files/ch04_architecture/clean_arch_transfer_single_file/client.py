import requests

print(requests.post('http://localhost:8051/api/transfer', data={'from_acct': '101000',
                                                                'to_acct': '121134',
                                                                'amount': 200.00}).text)

print(requests.post('http://localhost:8051/api/transfer', data={'from_acct': '101000',
                                                                'to_acct': '121134',
                                                                'amount': 1200.00}).text)
