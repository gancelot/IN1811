"""
    The example illustrates a very simple clean architecture where
    the use case is coded to "know" only about
    the outer layer (the repository, or gateway) in an abstract way.

    In other words, the database interactivity is performed via the abstract Store
    class, so that the use case knows nothing about which database is even used.

    This Store is our abstract class which is passed into the use case.
    Of course, changes to the abstract class does affect the use case, but
    generally the rule is to try not to change our interfaces
    (or, in Python, abstract classes).

    If this seems like extra layers of abstraction, this is what some people criticize
    about clean architectures in Python.  This architecture (it can be argued) goes
    against the philosophy (zen) of Python.

"""
from abc import ABC, abstractmethod


# use case
class SaveToDB:
    def __init__(self, abstract_db):
        self.db = abstract_db

    def save(self):
        self.db.save()


# gateway
class Store(ABC):
    def __init__(self):
        pass

    @abstractmethod
    def save(self):
        pass


class ActualDBImpl(Store):
    def __init__(self):
        super().__init__()

    def save(self):
        print('Perform database work...')


if __name__ == '__main__':
    dbImpl = ActualDBImpl()
    use_case = SaveToDB(dbImpl)
    use_case.save()
