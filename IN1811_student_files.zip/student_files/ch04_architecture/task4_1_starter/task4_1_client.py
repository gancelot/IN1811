import requests

base_url = 'http://localhost:8051'
path = '/api/team_roster/'
team_name = 'Arsenal'

print('Get roster:')
# Step 4. Make a get() call using requests.  Use the following URL: f'{base_url}{path}{team_name}'
#         From the return object, perform a .json()
#         Print the results.
