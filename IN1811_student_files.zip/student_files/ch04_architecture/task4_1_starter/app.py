"""

    app.py
    This implements a Flask service layer for retrieval of the Team Roster.
    Test by using: http://localhost:8051/api/team_roster/Arsenal

"""
from flask import Flask, jsonify, Response

from services.publish_roster import publish

app = Flask(__name__)


# Step 1.  Add the route.  Use a URL mapping of: '/api/team_roster/<name>' and methods=['GET']
def get_roster(name):
    status = 200

    try:
        # Step 2. Invoke the publish method, passing the (team) name.  It will return a team object.
        #         Invoke jsonify() passing the team and name as keyword arguments.  Use the same
        #         name for the key and the values (e.g., team=team, name=name)
        #         Save the return in an object called resp.
    except Exception as err:
        # Step 3. Complete jsonify passing in an empty team value (team=[]) and set
        #         name=err.args[0]
        resp = jsonify()
        # Also, set status to 404.

    return Response(resp.data, mimetype='application/json', status=status)


app.run(host='localhost', port=8051)

