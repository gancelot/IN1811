"""

    flask_server.py

    A sample server using Flask as our services layer.
    It does not use a separate domain model.  Instead it uses SQLAlchemy model classes to implement the
    repository pattern.

"""
from pathlib import Path
import sys

from flask import Flask, jsonify, Response, abort, request
from flask_sqlalchemy import SQLAlchemy

db_file = Path(__file__).parents[2] / 'resources/course_data.db'
if not db_file.exists():
    print(f'Database file does not exist at: {db_file}--exiting.', file=sys.stderr)
    sys.exit()

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + str(db_file)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


class CelebrityModel(db.Model):
    __tablename__ = 'celebrity'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    pay = db.Column(db.Float)
    year = db.Column(db.String(15))
    category = db.Column(db.String(50))

    def __init__(self, name, pay, year, category):
        self.name = name
        self.pay = pay
        self.year = year
        self.category = category

    def __str__(self):
        return f'{self.year} {self.name} {self.pay} {self.category}'

    def to_dict(self):
        return {'id': self.id, 'name': self.name, 'pay': self.pay, 'year': self.year, 'category': self.category}

    __repr__ = __str__


def handle_no_celebrity_exists_error(message: str = f'The specified celebrity doesn\'t exist.', error_code: int = 404):
    abort(error_code, message)
    return False


@app.route('/api/celebrities/id/<id>', methods=['GET'])
def get_one_celebrity(id):
    celeb = CelebrityModel.query.get(id)

    if not celeb:
        handle_no_celebrity_exists_error()

    resp = jsonify(results=celeb.to_dict(), id=id)
    return Response(resp.data, status=200, mimetype='application/json')


@app.route('/api/celebrities/<name>', methods=['GET'])
def get_all_celebrities(name):
    celebs = CelebrityModel.query.filter(CelebrityModel.name.contains(name)).all()

    if not celebs:
        handle_no_celebrity_exists_error()

    resp = jsonify(matches=[celeb_model.to_dict() for celeb_model in celebs], name=name)
    return Response(resp.data, status=200, mimetype='application/json')


@app.route('/api/celebrities', methods=['POST'])
def create_celebrity():
    try:
        name = request.form.get('name')
        year = request.form.get('year')
        category = request.form.get('category')
        pay = float(request.form.get('pay'))

        new_celeb = CelebrityModel(name, pay, year, category)
        db.session.add(new_celeb)
        db.session.commit()

        results = new_celeb.to_dict()
    except Exception as err:
        results = f'Error occurred on POST: {err}'

    resp = jsonify(results=results)
    return Response(resp.data, status=200, mimetype='application/json')


@app.route('/api/celebrities/id/<id>', methods=['PUT'])
def update_celebrity(id):
    try:
        name = request.form.get('name')
        year = request.form.get('year')
        category = request.form.get('category')
        pay = request.form.get('pay')

        celeb = CelebrityModel.query.get(id)

        if not celeb:
            handle_no_celebrity_exists_error()

        celeb.name = name
        celeb.year = year
        celeb.category = category
        celeb.pay = pay

        db.session.commit()

        results = celeb.to_dict()
    except Exception as err:
        results = f'Error occurred on PUT: {err}'

    resp = jsonify(results=results, id=id)
    return Response(resp.data, status=200, mimetype='application/json')


@app.route('/api/celebrities/id/<id>', methods=['DELETE'])
def delete_celebrity(id):
    try:
        celeb = CelebrityModel.query.get(id)

        if not celeb:
            handle_no_celebrity_exists_error()

        db.session.delete(celeb)
        db.session.commit()

        results = celeb.to_dict()
    except Exception as err:
        results = f'Error occurred on DELETE: {err}'

    resp = jsonify(results=results, id=id)
    return Response(resp.data, status=200, mimetype='application/json')


app.run(host='localhost', port=8051)
