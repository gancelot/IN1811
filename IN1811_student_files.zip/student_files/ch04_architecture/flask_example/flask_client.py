"""

    flask_client.py

"""
import requests

base_url = 'http://localhost:8051'
path = '/api/celebrities/'
single_path = 'id/'
celeb_name = 'Kevin'

print('\nGet all (for a partial name):')
r = requests.get(f'{base_url}{path}{celeb_name}')
results = r.json()
print(f'URL: {r.url}')
print(results)
matches = results.get('matches')

celeb_id = matches[0].get('id')
print(f'\nGet one (for id: {celeb_id})')
r = requests.get(f'{base_url}{path}{single_path}{matches[0].get("id")}')
print(f'URL: {r.url}')
results = r.json()
print(results)

print('\nPosting (creating a new celebrity):')
r = requests.post(f'{base_url}{path.rstrip("/")}', data={'name': 'Mandalorian', 'category': 'Character', 'pay': 3.0, 'year': 2020})
print(f'URL: {r.url}')
results = r.json()
print(results)

print('\nPutting (modifying our new celeb):')
r = requests.put(f'{base_url}{path}{single_path}{results.get("results").get("id")}',
                 data={'name': 'Boba Fett', 'category': 'Character', 'pay': 5.0, 'year': 2021})
print(f'URL: {r.url}')
results = r.json()
print(results)

print('\nDeleting (removing our new celeb):')
r = requests.delete(f'{base_url}{path}{single_path}{results.get("results").get("id")}')
print(f'URL: {r.url}')
results = r.json()
print(results)



