"""
    example06.py

    Before applying the decorator syntax.
    This version performs the function swap...short_formatter
"""


def short_formatter(func):
    width = 15
    def wrapper(val):
        val = val[:width] + '...'
        func(val)
    return wrapper


def long_formatter(func):
    width = 30
    def wrapper(val):
        val = val[:width] + '...'
        func(val)
    return wrapper


def display(val):
    print(val)

data = 'This is a long string that will be truncated.'
display(data)

display = long_formatter(display)
display(data)
