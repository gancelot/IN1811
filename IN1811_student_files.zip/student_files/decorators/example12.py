"""
    example12.py

    Fixing arguments for positional AND keywords
"""


def short_formatter(func):
    width = 15
    def wrapper(*args, **kwargs):
        arguments = []
        for arg in args:
            if isinstance(arg, str):
                arguments.append(arg[:width])
            else:
                arguments.append(arg)

        key_args = {}
        for key, val in kwargs.items():
            if isinstance(val, str):
                key_args[key] = val[:width]

        return func(*arguments, **key_args)
    return wrapper


@short_formatter
def display(val):
    print(val)


@short_formatter
def display_info(name, address):
    print(name, address)

data = 'This is a long string that will be truncated.'
display(data)
display_info('Johnny Kutchaketchakami', '124 Inner Redlands St.')
display_info('Johnny Kutchaketchakami', address='124 Inner Redlands St.')
