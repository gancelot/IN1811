"""
    example03.py

    Functions can exist within another function (closure)


"""
from urllib.request import urlopen


def set_url(url):
    def load():
        return urlopen(url).read()
    return load


get_cisco = set_url('http://www.cisco.com')
results = get_cisco()
print(results)
