"""
    example15.py
    Using the functools version of the cache...
"""
from functools import lru_cache


@lru_cache
def orig_func(*args, **kwargs):
    return f'Executing {orig_func.__name__} using {args, kwargs}'


print(orig_func(1))
orig_func(1, 2, 3)
orig_func('hello')
orig_func(1)
orig_func('hello')
orig_func(1, 2)
orig_func(1, 2, 'hello')
orig_func(1, val=2, item=3)
orig_func(1, val=2)
orig_func(1, val=2, item=3)
orig_func(1, item=3, val=2)

print(orig_func.cache_info())