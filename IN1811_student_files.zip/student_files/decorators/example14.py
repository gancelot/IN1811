"""
    example14.py
    Implementing a cache to a function call that may be expensive.
"""


def apply_cache(orig_func):
    cache = {}

    def wrapper(*args, **kwargs):
        args = list(args) + list(sorted(kwargs.items()))
        args = tuple(args)
        if args in cache:
            print(f'Using cache for {args}')
        else:
            print(f'Calling function for {args}')
            ret = orig_func(*args)
            cache[args] = (ret, ts)
        return cache[args]

    return wrapper


@apply_cache
def orig_func(*args, **kwargs):
    return f'Executing {orig_func.__name__} using {args, kwargs}'


orig_func(1)
orig_func(1, 2, 3)
orig_func('hello')
orig_func(1)
orig_func('hello')
orig_func(1, 2)
orig_func(1, 2, 'hello')
orig_func(1, val=2, item=3)
orig_func(1, val=2)
orig_func(1, val=2, item=3)
orig_func(1, item=3, val=2)
