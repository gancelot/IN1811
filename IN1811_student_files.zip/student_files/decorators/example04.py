def display_width(width):
    def display(val):
        print('in display')
        print(val[:width] + '...')
    return display


short_formatter = display_width(15)


data = 'This is a long string that will be truncated.'
short_formatter(data)
