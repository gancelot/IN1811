def short_formatter(func):
    width = 15
    def wrapper(*args, **kwargs):
        arguments = []
        for arg in args:
            if isinstance(arg, str):
                arguments.append(arg[:width])
            else:
                arguments.append(arg)
        return func(*arguments)
    return wrapper


@short_formatter
def display(val):
    print(val)


@short_formatter
def display_info(name, address=''):
    print(name, address)

data = 'This is a long string that will be truncated.'
display(data)
display_info('Johnny Kutchaketchakami', address='124 Inner Redlands St.')
