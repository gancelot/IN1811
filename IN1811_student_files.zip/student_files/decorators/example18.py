class output_formatter:
    def __init__(self, mask=None, allcaps=False):
        self.mask = mask
        self.allcaps = allcaps

    def other_methods(self):
        pass

    def __call__(self, orig_func):
        def wrapper(*args):
            self.other_methods()
            if self.allcaps:
                args = tuple([arg.upper() for arg in args])
            if self.mask:
                args = (args[0], '****') + args[2:]

            retval = orig_func(*args)
            return retval

        return wrapper


@output_formatter(mask=True, allcaps=True)
def my_func(first, last):
    print('{fn} {ln}'.format(fn=first, ln=last))


@output_formatter(False, allcaps=False)
def my_func2(first, last):
    print('{fn} {ln}'.format(fn=first, ln=last))

my_func('Bill', 'Smith')
my_func2('Bill', 'Smith')
