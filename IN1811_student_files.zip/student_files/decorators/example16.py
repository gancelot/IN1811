"""
    example16.py
    decorating a decorator...
"""


def lowercaser(func):
    def wrapper(*args, **kwargs):
        arguments = []
        for arg in args:
            if isinstance(arg, str):
                arg = arg.lower()
            arguments.append(arg)

        kwargs = {key:val.lower() for key, val in kwargs.items()
                    if isinstance(val, str)}
        return func(*arguments, **kwargs)

    return wrapper


def short_formatter(func):
    width = 15
    def wrapper(*args, **kwargs):
        arguments = []
        for arg in args:
            if isinstance(arg, str):
                arguments.append(arg[:width])
            else:
                arguments.append(arg)

        key_args = {}
        for key, val in kwargs.items():
            if isinstance(val, str):
                key_args[key] = val[:width]

        return func(*arguments, **key_args)
    return wrapper


@lowercaser
@short_formatter
def display_info(name, address):
    print(name, address)


display_info('Johnny Kutchaketchakami', '124 Inner Redlands St.')
display_info('Johnny Kutchaketchakami', address='124 Inner Redlands St.')
