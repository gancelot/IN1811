def short_formatter(orig_func):
    width = 15
    def wrapper(val):
        print('in wrapper')
        val = val[:width] + '...'
        orig_func(val)
    return wrapper




@short_formatter
def display(val):
    print(val)


# display = short_formatter(display)
data = 'This is a long string that will be truncated.'
display(data)
