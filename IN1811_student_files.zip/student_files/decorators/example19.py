"""
    Demonstrates the use of wraps, from functools.
    Run this, then remove the wraps inner decorator and run again.
    Note the difference.
"""
from functools import wraps


def preserve(orig_func):
    @wraps(orig_func)
    def wrapper(*args, **kwds):
        return orig_func(*args, **kwds)
    return wrapper


@preserve
def my_func():
    """
        Using wraps in the decorator preserves this string
        and the function name
    """
    print(my_func.__name__)
    print(my_func.__doc__)


my_func()
