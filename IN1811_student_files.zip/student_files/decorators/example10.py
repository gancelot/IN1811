def short_formatter(func):
    width = 15
    def wrapper(*args):
        val = val[:width] + '...'
        return func(val)
    return wrapper


@short_formatter
def display(val):
    print(val)


@short_formatter
def display_info(name, address):
    print(name, address)

data = 'This is a long string that will be truncated.'
display(data)
display_info('Johnny', '124 Main St.')
