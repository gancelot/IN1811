
def increment(val, amount):
    return val + amount


def decrement(val, amount):
    return val - amount


def op(func, data, amt):
    result = func(data, amt)
    return result


print(op(increment, 5, 3))
print(op(decrement, 3, 2))
