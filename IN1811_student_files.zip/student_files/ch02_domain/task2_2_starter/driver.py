from ch02_domain.task2_2_starter.domain.models import Team, Player
from ch02_domain.task2_2_starter.repository.base_store import StoreException
from ch02_domain.task2_2_starter.repository.team_store import TeamStore
from ch02_domain.task2_2_starter.repository.player_store import PlayerStore

try:
    ts = TeamStore()
    new_id = ts.add(Team('Depp', 'Owensboro, KY, USA'))
    team = ts.get(new_id)
    print('Team added: ', team)

    ps = PlayerStore()
    first_player_id = ps.add(Player('Jack Teague', 38, 'Goalkeeper', new_id))
    ps.add(Player('William Wonka', 56, 'Midfielder', new_id))
    ps.add(Player('Ed Scissorhands', 12, 'Defender', new_id))
    ps.add(Player('Gellert Grindelwald', 115, 'Forward', new_id))

    player = ps.get(first_player_id)
    print(player)

except StoreException as err:
    print(err)
