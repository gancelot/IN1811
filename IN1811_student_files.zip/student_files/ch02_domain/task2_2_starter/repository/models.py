from sqlalchemy import Column
from sqlalchemy.orm import declarative_base
from sqlalchemy.types import String, Integer


Base = declarative_base()


class TeamDTO(Base):
    __tablename__ = 'teams'
    id = Column('id', Integer, primary_key=True)
    common_name = Column(String(40))
    country = Column(String(40))

    def __init__(self,common_name, country):
        self.common_name = common_name
        self.country = country

    def __str__(self):
        return self.common_name

    __repr__ = __str__


class PlayerDTO(Base):
    __tablename__ = 'players'
    id = Column('id', Integer, primary_key=True, autoincrement=True)
    full_name = Column(String(50))
    age = Column(Integer)
    position = Column(String(40))
    team_id = Column(Integer)

    def __init__(self, full_name, age, position, team_id):
        self.full_name = full_name
        self.age = age
        self.position = position
        self.team = team_id

    def __str__(self):
        return f'{self.full_name} ({self.age}), {self.position}, {self.team_id}'

    __repr__ = __str__
