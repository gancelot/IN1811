"""

    working_with_the_db.py
    The following example shows how to access a database
    using the Python Database API.

"""
from pathlib import Path
import sqlite3
import sys

conn = None
try:
    db_url = Path(__file__).parents[1] / 'resources/course_data.db'
    conn = sqlite3.connect(db_url)
except sqlite3.Error as err:
    print(f'Error connecting to database. {err}')
    sys.exit(42)

print('Fetching a single result:')
team_id = 1
try:
    cursor = conn.cursor()
    cursor.execute('SELECT common_name, country, wins, draws, losses FROM teams WHERE id = ?', (team_id,))
    print(cursor.fetchone())
except sqlite3.Error as err:
    print(f'Database interaction error: {err}')

print('Fetching multiple records:')
try:
    cursor = conn.cursor()
    cursor.execute('SELECT common_name, country, wins, draws, losses FROM teams')
    for record in cursor:
        print(record)
except sqlite3.Error as err:
    print(f'Database interaction error: {err}')
