"""
    data_mapper.py
"""
from sqlalchemy import Table, Column, Integer, String
from sqlalchemy.orm import registry

mapper_registry = registry()

team_table = Table(
    'teams',
    mapper_registry.metadata,
    Column('id', Integer, primary_key=True),
    Column('full_name', String(50)),
    Column('age', Integer),
    Column('position', String(12)),
    Column('team_id', Integer),
)


class Team:
    pass


mapper_registry.map_imperatively(Team, team_table)
