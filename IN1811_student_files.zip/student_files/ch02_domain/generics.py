from dataclasses import dataclass
from typing import Generic, TypeVar

T = TypeVar('T')


@dataclass
class Team:
    common_name: str
    country: str


# this works when methods in children classes are very similar
class GenericStore(Generic[T]):
    def add(self, entity: T) -> None:
        # just an example...
        print('add() called for', type(entity).__name__, 'type.')

    def get(self, id: int) -> T:
        pass  # use id to retrieve entity for all types here


# you can optionally derive from the parent and override any differences in methods
# when some children classes have different method implementations
class TeamStore(GenericStore[Team]):
    def add(self, entity: Team) -> None:
        super().add(entity)  # in reality, put a different implementation code here

    def get(self, id: int) -> Team:
        pass  # put a different implementation code here

# or

ts = GenericStore[Team]()
ts.add(Team('Lakers', 'USA'))
ts.add(10)                       # add() will still be successfully called at runtime.

ts2 = TeamStore()
ts2.add(Team('Marlins', 'USA'))



