"""

    using_sqlalchemy.py
    Example showing the use of SQLAlchemy ORM to work with a database in Python.

"""
from pathlib import Path
from sqlalchemy import create_engine, Column
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy.types import String
from sqlalchemy.exc import SQLAlchemyError
import sys

db_url = Path(__file__).parents[1] / 'resources/course_data.db'


Base = declarative_base()


class NetflixTitle(Base):
    __tablename__ = 'netflix_titles'
    id = Column('show_id', String(10), primary_key=True)
    type = Column(String(20))
    title = Column(String(60))
    cast = Column(String(250))
    date_added = Column(String(40))
    rating = Column(String(10))


try:
    db = create_engine('sqlite:///' + str(db_url), echo=True)
    Session = sessionmaker(bind=db)
except SQLAlchemyError as err:
    print(f'Error connecting to database.  Error: {err}', file=sys.stderr)
    sys.exit()


def title_query(title: str):
    query_results = []
    try:
        with Session() as session:
            query_results = session.query(NetflixTitle).filter(NetflixTitle.title.like('%'+title+'%')).all()
    except SQLAlchemyError as err:
        print(f'Error working with db.  Error: {err}', file=sys.stderr)
    return query_results


results = title_query('Charlie')

format_str = '{0:<50} ({1}, {2})'
print(format_str.format('Title', 'Type', 'Rating'))
for record in results:
    print(format_str.format(record.title, record.type, record.rating))


# ------------------------------------------
# Retrieving objects by ID.
# Modifying them and saving them back.
try:
    with Session() as session:
        session.begin()
        show = session.query(NetflixTitle).get('s3393')
        print(show.title)
        show.title = '10 Days in Moon City'
        session.commit()
except SQLAlchemyError as err:
    print(f'Rolling back.  Error: {err}', file=sys.stderr)
    session.rollback()


# ------------------------------
# Undoing the change made.
try:
    with Session() as session:
        session.begin()
        show = session.query(NetflixTitle).get('s3393')
        print(show.title)
        show.title = '10 Days in Sun City'
        session.commit()
except SQLAlchemyError as err:
    print(f'Rolling back.  Error: {err}', file=sys.stderr)
    session.rollback()