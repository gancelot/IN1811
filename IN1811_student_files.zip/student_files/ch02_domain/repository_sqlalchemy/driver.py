from ch02_domain.repository_sqlalchemy.domain.models import Team
from ch02_domain.repository_sqlalchemy.repository.base_store import StoreException
from ch02_domain.repository_sqlalchemy.repository.team_store import TeamStore

try:
    ts = TeamStore()
    new_id = ts.add(Team('Depp', 'Owensboro, KY, USA'))
    team = ts.get(new_id)
    print(team)

    # Ignore this for now...to be added in task2-2
    # ps = PlayerStore()
    # first_player_id = ps.add(Player('Jack Teague', 38, 'Goalkeeper', new_id))
    # ps.add(Player('William Wonka', 56, 'Midfielder', new_id))
    # ps.add(Player('Ed Scissorhands', 12, 'Defender', new_id))
    # ps.add(Player('Gellert Grindelwald', 115, 'Forward', new_id))
    #
    # player = ps.get(first_player_id)
    # print(player)

except StoreException as err:
    print(err)
