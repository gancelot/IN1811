from sqlalchemy import Column
from sqlalchemy.orm import declarative_base
from sqlalchemy.types import String, Integer


Base = declarative_base()


class TeamDTO(Base):
    __tablename__ = 'teams'
    id = Column('id', Integer, primary_key=True)
    common_name = Column(String(40))
    country = Column(String(40))

    def __init__(self,common_name, country):
        self.common_name = common_name
        self.country = country

    def __str__(self):
        return self.common_name

    __repr__ = __str__
