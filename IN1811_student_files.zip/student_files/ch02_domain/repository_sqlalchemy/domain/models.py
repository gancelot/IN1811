from dataclasses import dataclass


@dataclass
class Team:
    common_name: str
    country: str
