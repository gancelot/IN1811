from dataclasses import dataclass


@dataclass
class Player:
    full_name: str
    age: int
    position: str
    team_id: int

    def __str__(self):
        return f'{self.full_name} ({self.age}), {self.position}'

    __repr__ = __str__


@dataclass
class Team:
    common_name: str
    country: str
