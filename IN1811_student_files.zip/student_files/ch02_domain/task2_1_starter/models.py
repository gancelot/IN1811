from dataclasses import dataclass


@dataclass
class Player:
    full_name: str = ''
    age: int = 0
    position: str = ''
    team_id: int = 0

    def __str__(self):
        return f'{self.full_name} ({self.age})'


@dataclass
class Team:
    common_name: str
    country: str
