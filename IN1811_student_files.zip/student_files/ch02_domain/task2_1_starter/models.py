from dataclasses import dataclass


# Step 1. Define a Player Dataclass with a full_name (str),
#         age (int), position (str), and team_id (int) datafields.
#         Optionally add a __str__ method to the class, its return value is not critical.



# Step 2. Repeat step 1, this time building a Team Dataclass.  It should have
#         a common_name (str) and country (str).  An __str__ method is not necessary here.
