from pathlib import Path
import sqlite3

from base_store import Store, StoreException
from models import Team


# Step 4. Have TeamStore inherit from the parent
class TeamStore():
    db_url = Path(__file__).parents[2] / 'resources/course_data.db'

    # Step 5. Override the connect() method from the parent.  It should invoke and return
    #         the sqlite3 module's connect() method passing the class' db_url variable

    # Step 6. Override the add() method from the parent.  This code would normally
    #         contain SQL code to INSERT an object into the database.
    #         The code within the method will look like the following:
    #     try:
    #         cursor = self.conn.cursor()
    #         cursor.execute('INSERT INTO teams (common_name, country) VALUES(?, ?)', (team.common_name, team.country))
    #         row_id = cursor.lastrowid
    #     except Exception:
    #         raise StoreException('Error adding team.') from err
    #     return row_id

    # Step 7. Override the get() method from the parent.  It will accept a team_id and
    #         return a Team (model) object.
    #         The code within the method will look like the following:
    #      try:
    #          cursor = self.conn.cursor()
    #          cursor.execute('SELECT common_name, country FROM teams  WHERE id = ?', (team_id,))
    #          results = cursor.fetchone()
    #      except Exception:
    #          raise StoreException('Error retrieving team.') from err
    #     return Team(*results)
