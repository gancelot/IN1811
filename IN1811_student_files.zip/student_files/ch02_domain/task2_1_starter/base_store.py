import abc


class StoreException(Exception):
    def __init__(self, message, *errors):
        super().__init__(message)
        self.errors = errors


class Store(abc.ABC):
    def __init__(self):
        try:
            self.conn = self.connect()
            print('Connection opened.')
        except Exception as err:
            raise StoreException('Error opening connection.') from err

    @abc.abstractmethod
    def connect(self):
        pass

    @abc.abstractmethod
    def add(self, model):
        pass

    @abc.abstractmethod
    def get(self, id):
        pass

    def __enter__(self):
        return self

    def __exit__(self, typ, msg, tb):
        self.close()

    def close(self):
        if self.conn:
            try:
                self.conn.commit()
                print('Data committed.')
            except Exception as err:
                self.conn.rollback()
                print('Data rolled back.')
                raise StoreException('Error working with store.') from err
            finally:
                if self.conn:
                    self.conn.close()
                    print('Connection closed.')
                else:
                    raise StoreException('Connection failed to close.')
