from pathlib import Path
import sqlite3

from base_store import Store, StoreException
from models import Player


# Step 8. Have PlayerStore inherit from the parent
class PlayerStore():
    db_url = Path(__file__).parents[2] / 'resources/course_data.db'

    # Step 9. Create a connect() method as done in step 5.


    # Step 10. Override add() from the parent as done in step 6.  Have this add() accept a Player object.
    # Use the following code for the database interactivity:
    #     try:
    #         cursor = self.conn.cursor()
    #         cursor.execute('INSERT INTO players (full_name, age, position, team_id) VALUES(?, ?, ?, ?)',
    #                        (player.full_name, player.age, player.position, player.team_id))
    #         row_id = cursor.lastrowid
    #     except Exception as err:
    #         raise StoreException('Error adding player.') from err
    #
    #     return row_id


    # Step 11. Override get() from the parent as done in step 7.
    #          Supply a player_id for the parameter to retrieve.
    #          Use the following code for the database interactivity.
    #     try:
    #         cursor = self.conn.cursor()
    #         cursor.execute('SELECT full_name, age, position, team_id FROM players  WHERE id = ?', (player_id,))
    #         results = cursor.fetchone()
    #     except Exception as err:
    #         raise StoreException('Error retrieving player.') from err
    #
    #     return Player(*results)
