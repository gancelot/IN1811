from pathlib import Path
import sqlite3

from base_store import Store, StoreException
from models import Player


class PlayerStore(Store):
    db_url = Path(__file__).parents[2] / 'resources/course_data.db'

    def connect(self):
        return sqlite3.connect(PlayerStore.db_url)

    def add(self, player: Player):
        try:
            cursor = self.conn.cursor()
            cursor.execute('INSERT INTO players (full_name, age, position, team_id) VALUES(?, ?, ?, ?)',
                           (player.full_name, player.age, player.position, player.team_id))
            row_id = cursor.lastrowid
        except Exception as err:
            raise StoreException('Error adding player.') from err

        return row_id

    def get(self, player_id) -> Player:
        try:
            cursor = self.conn.cursor()
            cursor.execute('SELECT full_name, age, position, team_id FROM players  WHERE id = ?', (player_id,))
            results = cursor.fetchone()
        except Exception as err:
            raise StoreException('Error retrieving player.') from err

        return Player(*results)
