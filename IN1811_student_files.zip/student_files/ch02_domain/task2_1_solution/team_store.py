from pathlib import Path
import sqlite3

from base_store import Store, StoreException
from models import Team


class TeamStore(Store):
    db_url = Path(__file__).parents[2] / 'resources/course_data.db'

    def connect(self):
        return sqlite3.connect(TeamStore.db_url)

    def add(self, team: Team) -> int:
        try:
            cursor = self.conn.cursor()
            cursor.execute('INSERT INTO teams (common_name, country) VALUES(?, ?)', (team.common_name, team.country))
            row_id = cursor.lastrowid
        except Exception as err:
            raise StoreException('Error adding team.') from err

        return row_id

    def get(self, team_id) -> Team:
        try:
            cursor = self.conn.cursor()
            cursor.execute('SELECT common_name, country FROM teams  WHERE id = ?', (team_id,))
            results = cursor.fetchone()
        except Exception as err:
            raise StoreException('Error retrieving team.') from err

        return Team(*results)
