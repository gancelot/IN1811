from models import Team, Player

from base_store import StoreException
from player_store import PlayerStore
from team_store import TeamStore

try:
    with TeamStore() as ts:
        team_id = ts.add(Team('Depp', 'Owensboro, KY, USA'))

    with PlayerStore() as ps:
        row_id = ps.add(Player('Iron Man', 12, 'Defender', team_id))

    with PlayerStore() as ps:
        print(ps.get(row_id))

except StoreException as err:
    print(err)
