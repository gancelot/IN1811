"""
    data_classes.py
"""
from dataclasses import dataclass
from typing import Set


@dataclass
class Customer:
    customer_id: int
    name: str


@dataclass
class Address:
    street: str
    city: str
    state: str
    zip: str


@dataclass
class OrderItem:
    id: str
    qty: int

    def __eq__(self, other):
        ret_val = False
        if other.id == self.id:
            ret_val = True
        return ret_val

    def __hash__(self):
        return hash(self.id)

    def __str__(self):
        return f'{self.id} ({self.qty})'

    __repr__ = __str__


@dataclass
class Order:
    status: str
    customer: Customer
    address: Address
    order_items: Set[OrderItem] = None

    def add_item(self, item: OrderItem):
        for order_item in self.order_items:
            if item.id == order_item.id:
                order_item.qty += item.qty
        else:
            self.order_items.add(item)

    def __str__(self):
        return f'{self.status}: ({self.customer.name}), {[item for item in self.order_items]}'


customer = Customer(1, 'John Smith')
address = Address('123 Main', 'Oakville', 'NY', '12888')
order = Order('New', customer, address, set())

item1 = OrderItem('100', 3)
item2 = OrderItem('110', 1)
item3 = OrderItem('100', 1)

order.add_item(item1)
order.add_item(item2)
order.add_item(item3)

print(order)
