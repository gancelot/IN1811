import app_vars

app_vars.name_size = 20
