import app_vars
import module2

print(app_vars.name_size)
