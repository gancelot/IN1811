from typing import List

from ch03_service.facade.services.repository.team_store import TeamStore
from ch03_service.facade.services.repository.player_store import PlayerStore


class AcquireRoster:
    def __init__(self, team_name: str):
        self.team_name = team_name

    def perform(self) -> List:
        ts = TeamStore()
        team_id = ts.find_by_name(self.team_name)

        ps = PlayerStore()
        players = ps.find_by_team(team_id)

        return players
