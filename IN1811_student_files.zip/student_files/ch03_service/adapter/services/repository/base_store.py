import abc


class StoreException(Exception):
    def __init__(self, message, *errors):
        super().__init__(message)
        self.errors = errors


class Store(abc.ABC):
    @abc.abstractmethod
    def connect(self):
        pass

    @abc.abstractmethod
    def add(self, model):
        pass

    @abc.abstractmethod
    def get(self, id):
        pass
