import abc
from typing import List, Union

from ch03_service.adapter.domain.models import Player
from ch03_service.adapter.services.pandas_player_adapter import PandasPlayerAdapter
from ch03_service.adapter.services.prepare_roster import PrepareRoster


class AbstractFactory(abc.ABC):
    @abc.abstractmethod
    def generate_preparer(self, typ, data):
        pass


class PrepareFactory(AbstractFactory):
    preparers = {'current': PrepareRoster, 'pandas': PandasPlayerAdapter}

    def generate_preparer(self, typ: str, data: Union[str, List[Player]]):
        return self.preparers.get(typ, PrepareRoster)(data)
