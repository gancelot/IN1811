"""
    send_email.py

    We simulate sending an email with an attachment to an SMTP server.
    We'll run an artificial (dummy) server to test this.

    To do this, from a command-line, run the command:

        python -m smtpd -c DebuggingServer -n localhost:1025

    where python is assumed to be the usual command you use to launch or interpreter
    localhost is the host to run the SMTP server on
    1025 is the chosen port to listen for email messages and should match the client
"""
from pathlib import Path
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.mime.text import MIMEText


class Email:
    def __init__(self, sent_from: str, sent_to: str, subject: str, attachment: str):
        self.email_msg = MIMEMultipart()
        self.email_msg['Subject'] = subject
        self.email_msg['From'] = sent_from
        self.email_msg['To'] = sent_to

        self.email_msg.attach(MIMEText(f'Attached is the following roster: {attachment}.'))

        attachment = Path(attachment)
        if not attachment.exists():
            raise Exception('PDF Attachment file not found.')
        part = MIMEApplication(attachment.read_text(), Name=attachment.name)
        part['Content-Disposition'] = f'attachment; filename="{attachment.name}"'
        self.email_msg.attach(part)

    def perform(self):
        server = smtplib.SMTP('localhost', 1025)
        server.send_message(self.email_msg)
        server.quit()
