"""
    To illustrate the adapter pattern, this method is a way to create the list of players
    in an alternate way than was developed in the facade example.

    The list of players is in the form of a Pandas dataframe.  It will need to be
    "adapted" to work with the publish() method.

"""
from pathlib import Path
import sqlite3

import pandas as pd

from ch03_service.adapter.services.repository.team_store import TeamStore


def gen_roster(team_name: str) -> pd.DataFrame:
    """
        This is presumed to be an older (or newer or different) way to acquire the roster
    """
    try:
        conn = sqlite3.connect(Path(__file__).parents[3] / 'resources/course_data.db')
        team_id = TeamStore().find_by_name(team_name)
        sql_query = 'SELECT full_name, age, position, team_id FROM players WHERE team_id = ?'
        return pd.read_sql(sql_query, conn, params=(team_id, ), columns=('Name', 'Age', 'Position', 'Team ID'))

    except Exception as err:
        print(f'Database error occurred: {err}')
        return pd.DataFrame(columns=('Name', 'Age', 'Position', 'Team ID'))


if __name__ == '__main__':
    print(gen_roster('Arsenal'))
