from typing import List

from reportlab.lib.colors import black, brown, lightskyblue, whitesmoke
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle


class PDFGenerator:
    def __init__(self, filename: str):
        self.doc_items = []
        self.doc = SimpleDocTemplate(filename, pagesize=letter,
                                     rightMargin=72, leftMargin=72,
                                     topMargin=72, bottomMargin=72, encoding='utf-8')

    def perform(self, data: List[List]) -> None:
        table = Table(data, colWidths=(200, 150, 100, 60))
        ts = TableStyle([('ALIGN', (0, 0), (-1, 0), 'CENTER'),
                         ('TEXTCOLOR', (0, 0), (-1, 0), brown),
                         ('ALIGN', (0, 1), (-1, -1), 'LEFT'),
                         ('GRID', (0, 0), (-1, -1), 1, black),
                         ('BACKGROUND', (0, 0), (-1, 0), lightskyblue),
                         ('BACKGROUND', (0, 1), (-1, -1), whitesmoke)
                         ])

        table.setStyle(ts)
        self.doc_items.append(table)
        self.doc.build(self.doc_items)
