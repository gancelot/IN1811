"""

    The adapter pattern attempts to allow an alternate
    (perhaps an older or newer implementation)
    to work with an existing one.

    To run this completely, you should ensure your SMTP server is running.  Use:
    python -m smtpd -c DebuggingServer -n localhost:1025 on the command line.

"""
from services.publish_roster import PublishRoster

PublishRoster().publish('Arsenal')
PublishRoster().publish('West Ham United', 'roster2.pdf')
PublishRoster().publish('Burnley', 'roster3.pdf')
PublishRoster().publish('foo', 'roster4.pdf')
