from services.publish_roster import publish

publish('Arsenal')

