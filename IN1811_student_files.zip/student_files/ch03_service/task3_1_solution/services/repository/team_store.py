from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import sessionmaker

from ch03_service.task3_1_solution.domain.models import Team
from ch03_service.task3_1_solution.services.repository.base_store import Store, StoreException
from ch03_service.task3_1_solution.services.repository.models import TeamDTO


class TeamStore(Store):
    db_url = Path(__file__).parents[4] / 'resources/course_data.db'
    db = create_engine('sqlite:///' + str(db_url), echo=True)

    def connect(self):
        try:
            return sessionmaker(bind=TeamStore.db)()
        except SQLAlchemyError as err:
            raise StoreException('Error getting session.') from err

    def add(self, team: Team):
        try:
            with self.connect() as session:
                teamDTO = TeamDTO(team.common_name, team.country)
                session.add(teamDTO)
                session.flush()
                session.refresh(teamDTO)
                id = teamDTO.id
                session.commit()
        except SQLAlchemyError as err:
            raise StoreException('Error adding team.') from err

        return id

    def get(self, team_id):
        try:
            with self.connect() as session:
                team_dto = session.query(TeamDTO).get(team_id)
                team = Team(team_dto.common_name, team_dto.country)
        except Exception as err:
            raise StoreException('Error retrieving team.') from err

        return team

    def find_by_name(self, team_name: str) -> int:
        id = 0
        try:
            with self.connect() as session:
                results = session.query(TeamDTO).filter(TeamDTO.common_name == team_name)
                if results.count() == 0:
                    raise StoreException('Team name not found.')
                id = results[0].id
        except Exception as err:
            raise StoreException('Error retrieving team by name.') from err

        return id
