"""
        text_message_factory.py
        Provides one concrete message factory implementation. (Is also the default
        implementation loaded by the driver.py)

"""
from abstract_factory import AbstractMessage, AbstractMessageFactory


class Plain(AbstractMessage):
    def __init__(self, msg):
        super().__init__(msg)

    def text(self):
        return self.msg


class Html(AbstractMessage):
    def __init__(self, msg):
        super().__init__(msg)

    def text(self):
        return f'<span>{self.msg}</span>'


class Json(AbstractMessage):
    def __init__(self, msg):
        super().__init__(msg)

    def text(self):
        return f'{{ "msg": "{self.msg}" }}'


class TextMessageFactory(AbstractMessageFactory):
    message_formats = {'text': Plain, 'html': Html, 'json': Json}

    def create_msg(self, msg_type, msg):
        return self.message_formats.get(msg_type, Plain)(msg)
