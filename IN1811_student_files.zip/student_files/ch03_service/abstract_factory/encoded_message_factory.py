"""
    encoded_message_factory.py

    Provides one concrete message factory implementation.
"""
import base64

from abstract_factory import AbstractMessage, AbstractMessageFactory


class EncodedMessage(AbstractMessage):
    def __init__(self, msg=''):
        super().__init__(msg)

    def encode(self):
        encoded = base64.b64encode(bytes(self.msg, 'utf-8'))
        print(encoded)
        return str(encoded, 'utf-8')


class EncodedPlain(EncodedMessage):
    def __init__(self, msg):
        super().__init__(msg)

    def text(self):
        return self.encode()


class EncodedHtml(EncodedMessage):
    def __init__(self, msg):
        super().__init__(msg)

    def text(self):
        return f'<span>{super().encode()}</span>'


class EncodedJson(EncodedMessage):
    def __init__(self, msg):
        super().__init__(msg)

    def text(self):
        return f'{{ "msg": "{super().encode()}" }}'


class EncodedMessageFactory(AbstractMessageFactory):
    message_formats = {'text': EncodedPlain, 'html': EncodedHtml, 'json': EncodedJson}

    def create_msg(self, msg_type, msg):
        return self.message_formats.get(msg_type, EncodedPlain)(msg)
