"""
    driver.py

    The abstract factory allows us to create families of classes without actually hard-coding the
    type of class we want to create.  We can also swap out the factory used to create the classes

    1) Run this as normal.
    2) Then, run this supplying a command-line argument of EncodedMessageFactory as in:
            python driver.py EncodedMessageFactory
       This will cause a different Factory to be used to construct messages.

"""
import argparse
import importlib
import re


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('factory', nargs='?', default='TextMessageFactory')
    return parser.parse_args()


factory = get_args().factory                                                # Ex: TextMessageFactory
mod_names = re.findall(r'[A-Z](?:[a-z]+|[A-Z]*(?=[A-Z]|$))', factory)       # ['Text', 'Message', 'Factory']
mod_name_str = '_'.join(mod_names).lower()                                  # 'text_message_factory'
mod = importlib.import_module(mod_name_str)                                 # text_message_factory (module)
Factory = getattr(mod, factory)                                             # TextMessageFactory (class)

factory = Factory()                                                         # TextMessageFactory() instance
msg_obj = factory.create_msg('html', 'Sample HTML msg.')
print(type(msg_obj), msg_obj.text())
msg_obj = factory.create_msg('json', 'Sample JSON msg.')
print(type(msg_obj), msg_obj.text())
msg_obj = factory.create_msg('text', 'A simple text msg.')
print(type(msg_obj), msg_obj.text())
