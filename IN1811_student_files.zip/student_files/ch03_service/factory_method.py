"""
    factory_method.py

    Simpler than the abstract factory pattern.
    It only concerns itself with creation of objects without hard-coding them.

"""
import abc


class Message(abc.ABC):
    def __init__(self, msg=''):
        self.msg = msg

    @abc.abstractmethod
    def text(self):
        pass


class Text(Message):
    def __init__(self, msg):
        super().__init__(msg)

    def text(self):
        return self.msg


class Html(Message):
    def __init__(self, msg):
        super().__init__(msg)

    def text(self):
        return f'<span>{self.msg}</span>'


class Json(Message):
    def __init__(self, msg):
        super().__init__(msg)

    def text(self):
        return f'{{ "msg": "{self.msg}" }}'


class MessageFactory:
    message_formats = {'text': Text, 'html': Html, 'json': Json}

    @classmethod
    def create_msg(cls, msg_type, msg):
        return cls.message_formats.get(msg_type, Text)(msg)


msg_obj = MessageFactory.create_msg('html', 'Sample HTML msg.')
print(type(msg_obj), msg_obj.text())
msg_obj = MessageFactory.create_msg('json', 'Sample JSON msg.')
print(type(msg_obj), msg_obj.text())
msg_obj = MessageFactory.create_msg('text', 'A simple text msg.')
print(type(msg_obj), msg_obj.text())
