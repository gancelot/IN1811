from abstract_handler import AbstractHandler


class DataEncoder(AbstractHandler):
    def process(self, data):
        data.append('went through DataEncoder')
        super().process(data)
