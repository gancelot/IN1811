from typing import List

from abstract_handler import AbstractHandler
from imputer import Imputer
from data_encoder import DataEncoder
from scaler import DataScaler


def clean_data(data, handler: AbstractHandler):
    handler.process(data)


def create_chain(handlers: List[AbstractHandler]):
    """
        Passes in a list and chains them together in the order given.
        Returns the first one in the chain to kick off the work.
    """
    if handlers:
        iter_handler = iter(handlers)
        current_handler = next(iter_handler)
        for handler in iter_handler:
            current_handler.next_in_process = handler
            current_handler = handler
    first_in_chain = handlers[0]

    return first_in_chain


# clean data...these can be placed in any order, in any quantity...
start = create_chain([Imputer(), Imputer(), DataScaler(), DataEncoder(), DataScaler()])

sample_data = ['This is some starting data']
clean_data(sample_data, start)
print(sample_data)
