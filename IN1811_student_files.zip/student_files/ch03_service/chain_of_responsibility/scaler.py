from abstract_handler import AbstractHandler


class DataScaler(AbstractHandler):
    def process(self, data):
        data.append('went through DataScaler')
        super().process(data)
