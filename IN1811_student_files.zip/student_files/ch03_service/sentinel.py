"""
    sentinel.py

    3 Examples of using sentinels including the third-party sentinels module which
    can differentiate between a missing value and an actual value that is a None value.


"""
# Example 1
s = 'A sample string'
print(s.find('sample'))
print(s.find('not there'))            # the return is a sentinel value


# Example 2
sentinel = -1
age = int(input('Enter an age (-1 to stop): '))
while age != sentinel:
    print(age)
    age = int(input('Enter an age (-1 to stop): '))



# -------------------------------
# Example 3: using sentinels module
#
from sentinels import NOTHING

populations = {
    'Cintra': 100_000,
    'Kings Landing': 250_000,
    'Asgard': None,
    'Wonderland': 400_000,
    'Emerald City': None
}


def find_population(name: str, default=None):
    return populations.get(name, default)


print(find_population('Emerald City'))
print(find_population('Emerald Citie'))


def find_population(name: str, default=NOTHING):
    return populations.get(name, default)

print(find_population('Emerald City'))
print(find_population('Emerald Citie'))