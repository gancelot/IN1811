"""

    pep8.py
    Rules to be aware of when coding in Python...

"""
from pathlib import Path
import sys
from typing import List, Tuple


# include two blank lines before and after a function definition (as shown here)
# variable and functions names should have underscores in multiple words
# Proper spacing for type hints is shown here
def load_data(filepath: str) -> List[Tuple]:      # -> list[tuple] in 3.9+
    results = []
    try:
        with Path(filepath).open(encoding='utf-8') as f:
            f.readline()
            for line in f:
                fields = line.strip().split(',')
                fullname = fields[0].split()
                first = fullname[0]
                if len(fullname) == 2:
                    last = fullname[1]

                employee = {'first': first, 'last': last}
                results.append((employee, *fields[1:]))
    except IOError as err:
        print(err, file=sys.stdout)

    return results


def display_name(employee: dict) -> None:
    first = employee.get('first')
    last = employee.get('last')
    print(f'{first} {last}')


datafile = '../resources/celebrity_100.csv'
data = load_data(datafile)
print(f'{len(data)} names found.')
for emp_data in data[:10]:
    display_name(emp_data[0])
