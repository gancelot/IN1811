"""

    idioms.py
    Some examples of Pythonic vs non-Pythonic coding.

"""
import csv
import itertools
import random

# ------------------------------
# Idioms involving Booleans
#


# When comparing values, use == over is
x = 0x2a
y = 6**2 + 6
print(x == y)
print(x is y)


# True, False, and None are singletons
def get_value():
    data = None
    val = random.randint(1, 10)
    if val % 2:
        data = val        # returns val if it's odd
    return data


value = get_value()
print(f'{value} == None, {value == None}')                 # for comparisons to True, False,
print(f'{value} is None, {value is None}')                 # and None use the 'is' keyword


# don't compare Boolean values to True or False
x = True
if x:                                     # favor this
    print(x)

if x == True:                             # over this
    print(x)


# favor readability
z = 10
if z is not None:                          # prefer this
    print(z)

if not z is None:                          # over this
    print(z)

fn = 'image.jpg'
if fn.endswith('jpg'):                     # prefer this
    print(fn)

if fn[:-3] == 'jpg':                       # over this
    print(fn)


# ------------------------------
# Idioms for iterating
#
with open('../resources/celebrity_100.csv', encoding='utf-8') as f:         # prefer this
    for count, line in enumerate(f):
        print(count, line.strip())


count = 0
with open('../resources/celebrity_100.csv', encoding='utf-8') as f:         # over this
    for line in f:
        print(count, line.strip())
        count += 1

print()


max_lines_to_read = 5
with open('../resources/celebrity_100.csv', encoding='utf-8') as f:         # prefer this
    f.readline()
    for line in itertools.islice(f, max_lines_to_read):
        print(line.strip())

count = 0
with open('../resources/celebrity_100.csv', encoding='utf-8') as f:         # over this
    f.readline()
    for line in f:
        print(line.strip())
        count += 1
        if count >= max_lines_to_read:
            break

print()
# ----------------------------------------
#   Use unpacking and don't care values
with open('../resources/celebrity_100.csv', encoding='utf-8') as f:         # prefer this
    f.readline()
    for name, pay, _, _ in itertools.islice(csv.reader(f), 3):
        print(name, pay)


with open('../resources/celebrity_100.csv', encoding='utf-8') as f:         # over this
    f.readline()
    for items in itertools.islice(csv.reader(f), 3):
        print(items[0], items[1])


with open('../resources/celebrity_100.csv', encoding='utf-8') as f:         # and over this
    f.readline()
    for name, pay, year, category in itertools.islice(csv.reader(f), 3):
        print(name, pay)

print()
# ----------------------------------------
#   Use generators


def get_names(filename: str = '../resources/celebrity_100.csv'):
    results = []

    with open(filename, encoding='utf-8') as f:
        f.readline()
        for name, _, _, _ in itertools.islice(csv.reader(f), 3):
            results.append(name)

    return results


for celebrity in get_names():
    print(celebrity)


def get_names(filename: str = '../resources/celebrity_100.csv'):
    with open(filename, encoding='utf-8') as f:
        f.readline()
        for name, _, _, _ in itertools.islice(csv.reader(f), 3):
            yield name


for celebrity in get_names():
    print(celebrity)
