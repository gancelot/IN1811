"""

    mini_task1.py
    The following example runs fine, but is written poorly.

    Instructions:
    There are numerous PEP-8 violations below.
    Clean up the code by following PEP-8 recommendations

    There are 3 poor uses of Python (aside from the PEP-8 violations)
    that need to be cleaned up.

    See if you can locate and fix as many as possible

"""
import pathlib
import sys


def load_data(filepath: str) -> list:
    results = []
    try:
        with pathlib.Path(filepath).open(encoding='utf-8'
                                         ) as f:
            f.readline()
            for line in f:
                fields = line.strip().split(',')
                fullname = fields[0].split()
                first = fullname[0]
                last = ''
                if len(fullname) == 2:
                    last = fullname[1]

                employee = {'first': first, 'last': last}
                results.append((employee, *fields[1:]))
    except IOError as err:
        print(err,
              file=sys.stdout)

    return results


def display_name(employee: dict) -> None:
    first = employee['first']
    last = employee['last']
    print(f'{first} {last}')


datafile = '../resources/celebrity_100.csv'
data = load_data(
                 datafile)

for name, _, _, _ in data[:10]:
    display_name(name)
