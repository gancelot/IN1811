"""

    inheritance.py
    Inheritance in Python.

"""
from pathlib import Path


class Person:
    def __init__(self, name: str, pay: int = 0):
        self.name = name
        self.pay = pay

    def __str__(self):
        return f'{self.name} ({self.pay})'


class Celebrity(Person):
    def __init__(self, name: str, pay: int = 0, year: int = 0, category: str = ''):
        super().__init__(name, pay)
        self.year = year
        self.category = category


celeb_data = Path('../resources/celebrity_100.csv') \
             .read_text(encoding='utf-8').split('\n', maxsplit=2)[1]

celeb = Celebrity(*celeb_data.split(','))
print(celeb)
