"""

    classes.py
    A basic Python class.

"""
from itertools import islice
from pathlib import Path


class Celebrity:
    def __init__(self, name: str, pay: int, year: str, category: str):
        self.name = name
        self.pay = pay
        self.year = year
        self.category = category

    def __str__(self):
        return f'{self.name} ({self.category})'

    __repr__ = __str__


filepath = Path('../resources/celebrity_100.csv')
with filepath.open(encoding='utf-8') as f:
    f.readline()
    for line in islice(f, 10):
        celeb = Celebrity(*line.strip().split(','))
        print(celeb)
