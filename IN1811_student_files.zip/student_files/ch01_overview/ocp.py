"""

    ocp.py


"""


class Persist:
    def get_connection(self):
        print('connect to db')

    def save(self):
        print('saving...')


class PersistOracle(Persist):
    def get_connection(self):
        super().get_connection()
        print('connect to oracle')


class PersistMySQL(Persist):
    def get_connection(self):
        super().get_connection()
        print('connect to MySQL')


def new_get_connection(self):
    print('new get connection')


Persist.get_connection = new_get_connection         # This violates OCP

p = PersistMySQL()
p.get_connection()
