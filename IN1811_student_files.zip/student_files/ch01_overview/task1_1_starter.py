"""

    task1_1_starter.py

    Use this file to test if you have set up your environment properly.
    After starting or re-starting PyCharm, the example code below should work...

"""
from pathlib import Path

from sqlalchemy import create_engine, Table, Column, Float, String
from sqlalchemy.orm import sessionmaker, registry

db_url = Path(__file__).parents[1] / 'resources/course_data.db'
db = create_engine('sqlite:///' + str(db_url))
session = sessionmaker(bind=db)()

mapper_registry = registry()

athletes_table = Table(
    'athletes',
    mapper_registry.metadata,
    Column('SNo', String(10), primary_key=True),
    Column('Name', String(60)),
    Column('Nationality', String(25)),
    Column('CurrentRank', String(10)),
    Column('PreviousYearRank', String(20)),
    Column('Sport', String(50)),
    Column('Year', String(15)),
    Column('Earnings', Float))


class Athlete:
    pass


mapper_registry.map_imperatively(Athlete, athletes_table)

results = session.query(Athlete).filter(Athlete.Earnings >= 100.0)
for athlete in results:
    print(f'{athlete.Name:<40}{athlete.Year:<10}{athlete.Earnings}')
