"""

    lsp.py


"""


class Quacker:
    def quack(self):
        print('quack!')

    def swim(self):
        print('splash!')


class Duck(Quacker):
    pass


class Frog(Quacker):
    pass


class Human:
    def quack(self):
        print('quack!')

    def swim(self):
        print('splash!')


class Fish:
    def swim(self):
        print('splash!')


class Pond:
    def interact(self, quacker: Quacker):
        quacker.quack()
        quacker.swim()


pond = Pond()
pond.interact(Duck())
pond.interact(Frog())
pond.interact(Human())
pond.interact(Fish())