"""

    mini_task1.py (Solution)
    Cleanup up version of our mini_task1.py code found in the root of ch01_overview

"""
from itertools import islice
from pathlib import Path
import sys


def load_data(filepath: str) -> list[tuple]:
    try:
        with Path(filepath).open(encoding='utf-8') as f:
            f.readline()
            for line in f:
                fields = line.strip().split(',')
                fullname = fields[0].split()
                first = fullname[0]
                last = fullname[-1] if len(fullname) > 1 else ''

                employee = {'first': first, 'last': last}
                yield employee, *fields[1:]
    except IOError as err:
        print(err, file=sys.stdout)


def display_name(employee: dict) -> None:
    first = employee.get('first')
    last = employee.get('last')
    print(f'{first} {last}')


datafile = '../../resources/celebrity_100.csv'
data = load_data(datafile)
for empl, _, _, _ in islice(load_data(datafile), 10):
    display_name(empl)
