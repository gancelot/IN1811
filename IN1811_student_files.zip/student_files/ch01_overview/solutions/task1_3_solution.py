"""

    task1_3_solution.py

"""
import abc
from datetime import date


class Athlete(abc.ABC):
    @abc.abstractmethod
    def __init__(self, full_name: str, age: int):
        self.full_name = full_name
        self.age = age

    def __str__(self):
        return self.full_name

    __repr__ = __str__


class Player(Athlete):
    def __init__(self, full_name: str, age: int, team_id: int, position: str):
        super().__init__(full_name, age)
        self.team_id = team_id
        self.position = position


class InjuredPlayer(Athlete):
    def __init__(self, full_name: str, age: int, team_id: int, return_date: date):
        super().__init__(full_name, age)
        self.team_id = team_id
        self.return_date = return_date


class Team:
    def __init__(self, name: str, team_id: int):
        self.name = name
        self.team_id = team_id
        self._roster: list[Athlete] = []

    @property
    def roster(self):
        return self._roster

    def add_athlete(self, athlete: Athlete):
        if not any(ath for ath in self._roster if athlete.full_name == ath.full_name):
            self._roster.append(athlete)


def add_to_roster(team: Team, athlete: Athlete):
    team.add_athlete(athlete)


if __name__ == '__main__':
    bulls_id = 1
    bulls = Team('Bulls', bulls_id)

    players = [Player('Michael Jordan', 23, bulls_id, 'Guard'),
               InjuredPlayer('Scottie Pippin', 28, bulls_id, date(1998, 4, 11))]

    for plr in players:
        add_to_roster(bulls, plr)
