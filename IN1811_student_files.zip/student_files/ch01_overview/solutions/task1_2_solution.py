"""

    task1_2_solution.py

"""
import abc
from typing import List


class Athlete(abc.ABC):
    @abc.abstractmethod
    def __init__(self, full_name: str, age: int):
        self.full_name = full_name
        self.age = age


class Player(Athlete):
    def __init__(self, full_name: str, age: int, team_id: int, position: str):
        super().__init__(full_name, age)
        self.team_id = team_id
        self.position = position


class Team:
    def __init__(self, name: str, id: int):
        self.name = name
        self.id = id
        self._roster: List[Player] = []                     # or list[Player] in 3.9+

    @property
    def roster(self) -> List[Player]:
        return self._roster

    def add_player(self, player: Player) -> None:
        if not any(plr for plr in self._roster if player.full_name == plr.full_name):
            self._roster.append(player)


bulls_id = 1
bulls = Team('Bulls', bulls_id)
jordan = Player('Michael Jordan', 23, bulls_id, 'Forward')
jordan2 = Player('Michael Jordan', 23, bulls_id, 'Forward')
bulls.add_player(jordan)
bulls.add_player(jordan2)                # shouldn't add this player
print(f'Number of players on roster: {len(bulls.roster)}')
print(bulls.roster[0].full_name)
