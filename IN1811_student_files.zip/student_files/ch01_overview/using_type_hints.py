"""
    using_type_hints.py
"""

from typing import NamedTuple, List, Tuple, Iterable, Iterator, Optional


# Example 1: Creation of many types, such as Player here, can be done by declaring types
#            for its attributes.  This structure is a typed NamedTuple
Player = NamedTuple('Player', [('name', str), ('height', int)])


# Example 2: Type hints can be used to declare types for parameters passed and return values
def create_player(name: str, height: int) -> Player:
    return Player(name, height)


create_player('John', 'tall')


# Example 3: Python 3.6 allowed individual variables to be declared with types.
#            Custom types can be created using the = sign.
name: str
height: int
TeamList = List[Player]


def update_team(names: Iterable[Tuple[str, str]], heights: Iterable[int], team_list: TeamList) -> None:
    for name, height in zip(names, heights):
        team_list.append(Player(' '.join(name), height))


team = []
update_team([('John', 'Smith')], (177,), team)
update_team([('Sally', 'Jones')], ('163',), team)


# Example 4: Python 3.9 allows the use of built-in types instead of the typing module
#            Use Union[] to declare that something can be one type or None.
#            Use Any to declare a type that can be anything
from typing import Union, Any
team: list[Player] = []
players: dict[str, tuple] = {'John': ('John', 177)}


def create_player(name: Union[str, None], height: Any) -> Player:
    if not name:
        name = 'Cristiano Ronaldo'
    return Player(name, height)


team.append(create_player('John', 'tall'))


# Example 5: Python 3.10 allows the Optional type to indicate something can be a declared type or None
#            (replaces Union[type, None])
#            And Python 3.10 allows the use of | to indicate type a or b
def create_player(name: Optional[str], height: int | float) -> Player:
    if not name:
        name = 'Cristiano Ronaldo'
    return Player(name, height)


create_player(None, 185)            # allowed
# create_player('John', 'tall')       # not allowed


# Example 6: A tuple of variable size
PlayerTuple = Tuple[str, int, ...]
tup1: PlayerTuple
tup2: PlayerTuple

tup1 = ('Cristiano Ronaldo', 10, 'Champion')    # allowed
tup2 = ('hello', 10)                            # not allowed


# Example 7: Generators are iterators so they're return type is Iterator.
#            Use the [type] notation to indicate what it yields
def gen(max_count: int) -> Iterator[int]:
    i = 0
    while i < max_count:
        yield i
        i += 1


for val in gen(5):
    print(val)
