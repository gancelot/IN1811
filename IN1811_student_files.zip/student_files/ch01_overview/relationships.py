"""

    relationships.py
    Modeling composition in Python.

"""
from pathlib import Path


class House:
    def __init__(self, sq_ft: int = 0, location: str = '', value: int = 0):
        self.sq_ft = sq_ft
        self.location = location
        self.value = value


class PrivateJet:
    def __init__(self, typ: str, capacity: int = 0, cost: int = 0):
        self.typ = typ
        self.capacity = capacity
        self.cost = cost


class Celebrity:
    def __init__(self, name: str, pay: int, year: str, category: str):

        self.plane = None
        self.houses = []

        self.name = name
        self.pay = pay
        self.year = year
        self.category = category


celeb_data = Path('../resources/celebrity_100.csv') \
             .read_text(encoding='utf-8').split('\n', maxsplit=2)[1]

celeb = Celebrity(*celeb_data.split(','))
celeb.plane = PrivateJet('Gulfstream 550', 16, 40_000_000)
celeb.houses.append(House(23_000, 'Santa Barbara, CA', 50_000_000))
celeb.houses.append(House(7_300, 'Orcas Island, WA', 8_300_000))
celeb.houses.append(House(5_000, 'Santa Ynez, CA', 29_000_000))
celeb.houses.append(House(location='Montecito, CA', value=7_000_000))
celeb.houses.append(House(8_700, 'Telluride, CO', 14_000_000))
celeb.houses.append(House(location='Maui, HA', value=32_000_000))
