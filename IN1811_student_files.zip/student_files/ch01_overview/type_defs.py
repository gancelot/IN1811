"""

    type_defs.py
    Understanding how type hints (annotations) have evolved

"""
from typing import Union, Optional, Any, List, Tuple, NamedTuple, Dict, Iterable


# A typed namedtuple added in Python 3.6
Player = NamedTuple('Player', [('name', str), ('height', int)])


# Use of type hints within functions started in Python 3.5
def create_player(name: str, height: int) -> Player:
    return Player(name, height)


create_player('John', 'tall')       # 'tall' should be an int


# -----------------------------------------------
# Python 3.6 added type hints to variables
name: str
height: int
TeamList = List[Player]


def update_team(names: Iterable[Tuple[str, str]], heights: Iterable[int], team_list: TeamList) -> None:
    for name, height in zip(names, heights):
        team_list.append(Player(' '.join(name), height))

team = []
update_team([('John', 'Smith')], (177,), team)
update_team([('Sally', 'Jones')], ('163',), team)
print (team)


# ------------------------------------------------
# Python 3.9+
from typing import Union, Optional, Any, List, Tuple, NamedTuple, Dict, Iterable
team: list[Player] = []
players: dict[str, tuple] = {'John': ('John', 177)}


def create_player(name: Union[str, None], height: Any) -> Player:
    if not name:
        name = 'Cristiano Ronaldo'
    return Player(name, height)


team.append(create_player('John', 'tall'))


# -----------------------------------------------
# Python 3.10 only, comment these lines out if not using 3.10
def create_player(name: Optional[str], height: int | float) -> Player:
    if not name:
        name = 'Cristiano Ronaldo'
    return Player(name, height)


create_player(None, 185)            # allowed
create_player('John', 'tall')       # not allowed
