"""

    task1_2_starter.py

"""
import abc


# Step 1. Create the Athlete class.  Make it abstract.
#         Provide an __init__() method and make it abstract.  Allow a full_name (str) and age (int) to
#         be passed in and attached to the object (using self)
#
#         It can help to create a __repr__() magic method that returns the full_name.


# Step 2. Create a Player that inherits from Athlete.  Pass in a full_name, age,
#         team_id (int), and position (str).  Call the base class __init__ using super.


# Step 3. Create the Team class.
#         Provide a name and team_id as parameters to the __init__.
#         Establish in the __init__ a _roster attribute that is a list of Players
#         self._roster: list[Player] = []
#
#         Create a roster read-only property as follows:
#             @property
#             def roster(self):
#                 return self._roster
#
#         Create an add_player() method.  Check (the name) to see that the player is not
#         already on the roster.  The following code uses a list comprehension to do this...

#         if not any(plr for plr in self._roster if player.full_name == plr.full_name):
#             self._roster.append(player)


bulls_id = 1
bulls = Team('Bulls', bulls_id)
jordan = Player('Michael Jordan', 23, bulls_id, 'Forward')
jordan2 = Player('Michael Jordan', 23, bulls_id, 'Forward')
bulls.add_player(jordan)
bulls.add_player(jordan2)                # shouldn't add this player
print(f'Number of players on roster: {len(bulls.roster)}')
print(bulls.roster[0].full_name)
