"""

    task1_3_starter.py

"""
import abc
from datetime import date


class Athlete(abc.ABC):
    @abc.abstractmethod
    def __init__(self, full_name: str, age: int):
        self.full_name = full_name
        self.age = age

    def __str__(self):
        return self.full_name

    __repr__ = __str__


class Player(Athlete):
    def __init__(self, full_name: str, age: int, team_id: int, position: str):
        super().__init__(full_name, age)
        self.team_id = team_id
        self.position = position


# Step 1. Create an InjuredPlayer class that inherits from Athlete.  Create an __init__
#         that accepts a full_name, age, team_id, and return_date.  Invoke the parent __init__.


class Team:
    def __init__(self, name: str, id: int):
        self.name = name
        self.id = id
        self._roster: list[Player] = []        # Step 4. Change to list[Athlete]

    @property
    def roster(self):
        return self._roster

    # Step 2. Modify the add_player() method, renaming it to add_athlete() and have it
    #         accept an athlete parameter.
    def add_player(self, player: Player):
        if not any(plr for plr in self._roster if player.full_name == plr.full_name):
            self._roster.append(player)


# Step 3.  Change this method to use DIP.  Have it accept an Athlete instead of a Player.
def add_to_roster(team: Team, player: Player):
    team.add_player(player)


if __name__ == '__main__':
    bulls_id = 1
    bulls = Team('Bulls', bulls_id)

    # Step 4. Create an InjuredPlayer object and add it to the list of players below.
    #         Supply values for it such as 'Scottie Pippin', 28, bulls_id, date(1998, 4, 11)
    #         Modify the call to add_player() below and also add the InjuredPlayer to the roster
    players = [Player('Michael Jordan', 23, bulls_id, 'Guard'),
               # add injured player here
               ]

    for plr in players:
        add_to_roster(bulls, plr)



