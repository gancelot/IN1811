"""

    isp.py


"""


class Order:
    def add_item(self):
        pass

    def remove_item(self):
        pass

    def subtotal(self):
        pass

    def confirm(self):
        pass

    def close(self):
        pass

    def dispatch(self):
        pass

    def check_customer_status(self):
        pass

    def check_inventory(self):
        pass


class NormalOrder(Order):
    pass


class CustomOrder(Order):
    def check_inventory(self):          # this method is not needed in the CustomOrder
        pass