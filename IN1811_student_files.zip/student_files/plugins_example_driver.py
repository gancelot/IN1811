from plugin import plugin_mgr


plugin_mgr.run_plugins()                            # runs all plugins

plugin_mgr.get_plugin(name='Plugin1').execute()     # runs one plugin with given name
