import abc
from typing import List

import colorama


class Event:
    def __init__(self, msg):
        self.msg = msg


class Chatter(abc.ABC):
    @abc.abstractmethod
    def send(self, event: Event):
        pass

    @abc.abstractmethod
    def receive(self, event: Event):
        pass


class Mediator(abc.ABC):
    def __init__(self):
        self.chatters: List[Chatter] = []

    @abc.abstractmethod
    def broadcast(self, event: Event):
        pass


class Room(Mediator):
    def broadcast(self, event: Event):
        for chatter in self.chatters:
            chatter.receive(event)


class Avatar(Chatter):
    def __init__(self, name, mediator):
        self.name = name
        self.mediator = mediator
        mediator.chatters.append(self)
        join_msg = f'{self.name} has joined.'
        mediator.broadcast(Event(join_msg))

    def send(self, event: Event):
        print(colorama.Fore.GREEN, f'{self.name} sent: {event.msg}')
        self.mediator.broadcast(event)

    def receive(self, event: Event):
        color = colorama.Fore.MAGENTA
        if 'join' in event.msg:
            color = colorama.Fore.BLUE
        print(color, f'{self.name} received: {event.msg}')


if __name__ == '__main__':
    room = Room()
    chatter1 = Avatar('John', room)
    chatter2 = Avatar('Sally', room)
    chatter1.send(Event('Hey, everyone!'))
    chatter2.send(Event('Hey, John!'))
    chatter3 = Avatar('Mila', room)
    chatter3.send(Event('Hello.'))
