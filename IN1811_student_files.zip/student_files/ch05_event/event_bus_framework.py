from event_bus import EventBus

bus = EventBus()


@bus.on('default')
def subscriber(msg):
    print(msg)


def publish(msg: str, channel: str = 'default'):
    bus.emit(channel, msg)


publish('This is an emitted message.')