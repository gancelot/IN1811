import abc
from collections import defaultdict


class Event:
    def __init__(self, state):
        self.state = state

    def __str__(self):
        return str(self.state)

    __repr__ = __str__


class AbstractSubscriber(abc.ABC):
    @abc.abstractmethod
    def __init__(self):
        pass

    @abc.abstractmethod
    def update(self, event: Event):
        pass


class Subscriber(AbstractSubscriber):
    def __init__(self):
        self.state = {}

    def update(self, event: Event):
        self.state = event.state
        print(f'{self.__class__.__name__}: {event}')


class Publisher:
    def __init__(self):
        # Step 1. Change self.subscribers to be a defaultdict type with the value defaultdict(list)
        self.subscribers: list[AbstractSubscriber] = []

    # Step 2. Modify the add() function to accept a channel parameter.  It is a string with a default value of 'default'
    #         Also modify the line within this function to support a channel:
    #                 self.subscribers[channel].append(observer)
    def add(self, observer: AbstractSubscriber):
        self.subscribers.append(observer)

    # Step 3. Modify the remove() function in almost the exact same way as add() except,
    #         instead of calling the append() function, you will call remove().
    #         Ensure the function accepts a channel parameter in the same way as above
    def remove(self, observer: AbstractSubscriber):
        try:
            self.subscribers.remove(observer)
        except ValueError:
            pass

    # Step 4. Modify the publish() function to take a channel argument as done above.
    #         Iterate over the subscribers for that channel, as in:
    #                   for subscriber in self.subscribers[channel]:
    def publish(self, event: Event):
        for subscriber in self.subscribers:
            subscriber.update(event)


if __name__ == '__main__':

    publisher = Publisher()

    subscriber1 = Subscriber()
    subscriber2 = Subscriber()

    publisher.add(subscriber1)
    publisher.add(subscriber1, 'preferred')
    publisher.add(subscriber2, 'preferred')

    publisher.publish(Event('The next newsletter has arrived!'), 'preferred')
    publisher.publish(Event('Another newsletter will be released soon!'))

    publisher.remove(subscriber1)

    publisher.publish(Event('No one will receive this because no one is on the default channel.'))
