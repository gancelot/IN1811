import abc


class Event:
    def __init__(self, state):
        self.state = state

    def __str__(self):
        return str(self.state)

    __repr__ = __str__


class AbstractSubscriber(abc.ABC):
    @abc.abstractmethod
    def __init__(self):
        pass

    @abc.abstractmethod
    def update(self, event: Event):
        pass


class Subscriber(AbstractSubscriber):
    def __init__(self):
        self.state = {}

    def update(self, event: Event):
        self.state = event.state
        print(f'{self.__class__.__name__}: {event}')


class Publisher:
    def __init__(self):
        self.subscribers: list[AbstractSubscriber] = []

    def add(self, observer: AbstractSubscriber):
        self.subscribers.append(observer)

    def remove(self, observer):
        try:
            self.subscribers.remove(observer)
        except ValueError:
            pass

    def publish(self, event: Event):
        for subscriber in self.subscribers:
            subscriber.update(event)


if __name__ == '__main__':

    publisher = Publisher()

    subscriber1 = Subscriber()
    publisher.add(subscriber1)

    subscriber2 = Subscriber()
    publisher.add(subscriber2)

    publisher.publish(Event('The next newsletter has arrived!'))
    publisher.remove(subscriber1)

    publisher.publish(Event('Another newsletter will be released soon!'))
