"""

    TeamStore is a custom iterable that implements __iter__ and __next__ magic methods.

"""
import sqlite3
from pathlib import Path


class TeamStore(object):
    db_url = Path(__file__).parents[1] / 'resources/course_data.db'

    def __init__(self):
        self.results = self._get()

    def __iter__(self):
        self._i = 0
        return self

    def __next__(self):
        self._i += 1
        if self._i > len(self.results):
            raise StopIteration
        else:
            current_value = self.results[self._i - 1]
        return current_value

    def _get(self) -> list[tuple]:
        try:
            with sqlite3.connect(self.db_url) as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT common_name, country FROM teams')
                return cursor.fetchall()
        except sqlite3.Error as err:
            print(err)
            return []


for team in TeamStore():
    print(team)

ts_iter = iter(TeamStore())
result = next(ts_iter)         # incurs a StopIteration
print(result)
