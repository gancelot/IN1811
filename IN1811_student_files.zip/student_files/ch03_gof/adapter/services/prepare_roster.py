class PrepareRoster:
    def __init__(self, data, header: tuple = ('Name', 'Age', 'Position', 'Team ID')):
        self.header = header
        self.data = data

    def perform(self) -> list[list]:
        results = [self.header]
        results.extend([player.to_list() for player in self.data])
        return results
