import sys

from ch03_gof.adapter.services.acquire_roster import AcquireRoster
from ch03_gof.adapter.services.send_email import Email
from ch03_gof.adapter.services.pdf_generator import PDFGenerator
from ch03_gof.adapter.services.factory import PrepareFactory
from ch03_gof.adapter.services.repository.base_store import StoreException


class PublishRoster:
    def publish(self, team_name: str, filename: str = 'roster.pdf') -> None:
        """
        For the adapter example, focus only on the call to generate_roster_preparer().

        This version of our publish roster prepares the data for PDF generation in one of two ways:
        1) By passing players into generate_roster_preparer() which returns a PrepareRoster() object instance, or
        2) By passing a team name (e.g., 'Arsenal') into generate_roster_preparer() which returns a PandasPlayerAdapter instance.

        If a team name is passed into generate_roster_preparer() the adapter calls a different method
        entirely to acquire the team roster from the database (it uses Pandas).

        """
        players = []
        try:
            players = AcquireRoster(team_name).perform()
        except StoreException as err:
            print(f'StoreException--> {err}', file=sys.stderr)


        preparer = PrepareFactory().generate_preparer('pandas', team_name)
        # alternatively, replace the above with the version below to use
        # a different class that prepares the data for PDF generation
        # preparer = PrepareFactory().generate_preparer('current', players)

        players_prepped = preparer.perform()

        print('Roster before PDF Gen:')
        print(players_prepped)

        PDFGenerator(filename).perform(players_prepped)

        email = Email('joe@yahoo.com', 'sally@gmail.com', 'Team Roster', filename)
        try:
            email.perform()
        except ConnectionError as err:
            print('\n\n')
            print(f'Email not sent.  Check that your SMTP server is running.\nError: {err}', file=sys.stdout)
            print('\n\n')
