import ch03_gof.adapter.services.old_prepare_roster as adaptee


class PandasPlayerAdapter:
    def __init__(self, team_name):
        self.team_name = team_name

    def perform(self) -> list[list]:
        df = adaptee.gen_roster(self.team_name)

        header = list(df.columns)
        results = df.values.tolist()                              # df.to_numpy().tolist()
        results.insert(0, header)

        return results
