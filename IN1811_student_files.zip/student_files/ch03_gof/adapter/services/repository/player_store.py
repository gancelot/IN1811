from pathlib import Path
from typing import List

from sqlalchemy import create_engine
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import sessionmaker

from ch03_gof.adapter.domain.models import Player
from ch03_gof.adapter.services.repository.base_store import Store, StoreException
from ch03_gof.adapter.services.repository.models import PlayerDTO


class PlayerStore(Store):
    db_url = Path(__file__).parents[4] / 'resources/course_data.db'
    db = create_engine('sqlite:///' + str(db_url), echo=True)

    def connect(self):
        try:
            return sessionmaker(bind=PlayerStore.db)()
        except SQLAlchemyError as err:
            raise StoreException('Error getting session.') from err

    def add(self, player: Player):
        try:
            with self.connect() as session:
                playerDTO = PlayerDTO(player.full_name, player.age, player.position, player.team_id)
                session.add(playerDTO)
                session.flush()
                session.refresh(playerDTO)
                id = playerDTO.id
                session.commit()
        except SQLAlchemyError as err:
            raise StoreException('Error adding team.') from err

        return id

    def get(self, player_id) -> Player:
        try:
            with self.connect() as session:
                playerDTO = session.query(PlayerDTO).get(player_id)
                player = Player(playerDTO.full_name, playerDTO.age, playerDTO.position, playerDTO.team_id)
        except Exception as err:
            raise StoreException('Error retrieving team.') from err

        return player

    def find_by_team(self, team_id: int) -> List[Player]:
        players = []
        try:
            with self.connect() as session:
                results = session.query(PlayerDTO).filter(PlayerDTO.team_id == team_id)
                for playerDTO in results:
                    players.append(Player(playerDTO.full_name, playerDTO.age, playerDTO.position, playerDTO.team_id))
        except Exception as err:
            raise StoreException('Error retrieving team by name.') from err

        return players
