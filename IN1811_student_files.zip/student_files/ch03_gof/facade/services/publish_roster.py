import sys

from ch03_gof.facade.services.acquire_roster import AcquireRoster
from ch03_gof.facade.services.send_email import Email
from ch03_gof.facade.services.pdf_generator import PDFGenerator
from ch03_gof.facade.services.prepare_roster import PrepareRoster
from ch03_gof.facade.services.repository.base_store import StoreException


class PublishRoster:
    def publish(self, team_name: str, filename: str = 'roster.pdf') -> None:
        """
            Facade method:
            - acquires the roster from the DB through the UoW and repository
            - prepares the roster (as a list of lists)
            - generates the PDF
            - emails the roster

        """
        players = []
        try:
            players = AcquireRoster(team_name).perform()
        except StoreException as err:
            print(f'StoreException--> {err}', file=sys.stderr)

        players_prepped = PrepareRoster(players).perform()
        print('Roster before PDF Gen:')
        print(players_prepped)

        PDFGenerator(filename).perform(players_prepped)

        email = Email('joe@yahoo.com', 'sally@gmail.com', 'Team Roster', filename)
        try:
            email.perform()
        except ConnectionError as err:
            print('\n\n')
            print(f'Email not sent.  Check that your SMTP server is running.\nError: {err}', file=sys.stdout)
            print('\n\n')
