"""

    The facade pattern attempts to present a simplified interface to the user.  Here,
    our solution tries to build a roster.  To do this it first acquires it from the
    database, converts it to a proper format to be used by ReportLab (a list of lists
    instead of a list of players), generates the PDF in ReportLab, sends and email of
    the roster.

    This potentially messy interface is remedied by the facade that has
    turned the work into a single simple call shown below.

    To run this completely, you should ensure your SMTP server is running.  Use:
    python -m smtpd -c DebuggingServer -n localhost:1025 on the command line.

"""
from services.publish_roster import PublishRoster

PublishRoster().publish('Arsenal')
PublishRoster().publish('West Ham United', 'roster2.pdf')
PublishRoster().publish('Burnley', 'roster3.pdf')
PublishRoster().publish('foo', 'roster4.pdf')
