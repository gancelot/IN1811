"""

    abstract_factory.py
    Provides the abstract classes used by the messaging system
"""

import abc


class AbstractMessageFactory(abc.ABC):
    @abc.abstractmethod
    def create_msg(self, msg_type, msg):
        pass


class AbstractMessage(abc.ABC):
    def __init__(self, msg=''):
        self.msg = msg

    @abc.abstractmethod
    def text(self):
        pass
