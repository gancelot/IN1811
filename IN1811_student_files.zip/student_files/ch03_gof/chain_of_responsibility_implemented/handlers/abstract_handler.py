import abc
from typing import Any


class AbstractHandler(abc.ABC):
    def __init__(self):
        self._next_in_process = None

    @property
    def next_in_process(self):
        return self._next_in_process

    @next_in_process.setter
    def next_in_process(self, next_handler):
        self._next_in_process = next_handler

    @abc.abstractmethod
    def process(self, data: Any):
        if self.next_in_process:
            return self.next_in_process.process(data)
