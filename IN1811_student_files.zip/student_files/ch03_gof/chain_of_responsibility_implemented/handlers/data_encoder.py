from . import AbstractHandler


class DataEncoder(AbstractHandler):
    """Performs categorical encoding on the stated column only"""
    def __init__(self, col_name: str):
        super().__init__()
        self.col_name = col_name

    def process(self, data):
        data[self.col_name] = data[self.col_name].astype('category')
        data[self.col_name + '_enc'] = data[self.col_name].cat.codes
        super().process(data)
