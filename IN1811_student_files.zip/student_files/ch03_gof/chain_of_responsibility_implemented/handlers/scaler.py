from . import AbstractHandler

import pandas as pd

class DataScaler(AbstractHandler):
    """Performs minmax scaling on the stated column only"""
    def __init__(self, col_name: str, minmax: bool = True):
        super().__init__()
        self.col_name = col_name
        self.minmax = minmax

    def process(self, data):
        if self.minmax:
            min = data[self.col_name].min()
            max = data[self.col_name].max()
            data[self.col_name] = (data[self.col_name] - min) / (max - min)
        super().process(data)
