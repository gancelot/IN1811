import pandas as pd

from . import AbstractHandler


class Imputer(AbstractHandler):
    def __init__(self, col_name: str = None):        # None implies impute for ALL columns
        super().__init__()
        self.col_name = col_name


class MedianImputer(Imputer):

    def process(self, data: pd.DataFrame):
        if not self.col_name:
            for col_name in data:
                impute_val = data[col_name].median()
                data.fillna({col_name: impute_val}, inplace=True)
        else:
            impute_val = data[self.col_name].median()
            data.fillna({self.col_name: impute_val}, inplace=True)

        super().process(data)
