from pathlib import Path

import numpy as np
import pandas as pd

from handlers import AbstractHandler, MedianImputer, DataEncoder, DataScaler


class ChainOfResponsibility:
    def __init__(self, data: pd.DataFrame, steps: list[AbstractHandler]):
        self.data = data
        self.first = self._create_chain(steps)

    def run(self):
        self.first.process(self.data)

    def _create_chain(self, handlers: list[AbstractHandler]):
        """
            Passes in a list and chains them together in the order given.
            Returns the first one in the chain to kick off the work.
        """
        if handlers:
            iter_handler = iter(handlers)
            current_handler = next(iter_handler)
            for handler in iter_handler:
                current_handler.next_in_process = handler
                current_handler = handler
        return handlers[0]


if __name__ == '__main__':
    steps = [MedianImputer('score1'), MedianImputer(), DataScaler('score2'), DataEncoder('score1')]
    sample_data = pd.DataFrame({
        'score1': [100, 90, np.nan, 95],
        'score2': [30, 45, 56, np.nan],
        'score3': [np.nan, 40, 80, 98]
    })
    print(sample_data)
    chain = ChainOfResponsibility(sample_data, steps)
    chain.run()
    print(sample_data)
