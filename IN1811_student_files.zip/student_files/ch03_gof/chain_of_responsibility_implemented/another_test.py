"""

    A second test of ChainOfResponsibility reads the celebrity_100.csv file
    and encodes the Category column and normalizes the Pay column.

"""
from pathlib import Path

import pandas as pd

from handlers import DataEncoder, DataScaler

from cor import ChainOfResponsibility

data = pd.read_csv(Path(__file__).parents[2] / 'resources/celebrity_100.csv')

steps = [DataScaler('Pay (USD millions)'), DataEncoder('Category')]
c = ChainOfResponsibility(data, steps)
c.run()
print(data)
