import sys

from ch03_gof.task3_1_starter.services.acquire_roster import acquire_roster
from ch03_gof.task3_1_starter.services.repository.base_store import StoreException


def publish(team_name: str) -> None:
    players = []
    try:
        players = acquire_roster(team_name)
    except StoreException as err:
        print(f'StoreException--> {err}', file=sys.stderr)

    print(players)

    # The tasks below are implemented in the facade pattern example later:
    # prepare the roster
    # generate a PDF of the roster
    # attach into an email
    # send it
