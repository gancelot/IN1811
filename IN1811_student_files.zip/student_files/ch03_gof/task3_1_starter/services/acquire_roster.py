from ch03_gof.task3_1_starter.services.repository.team_store import TeamStore
from ch03_gof.task3_1_starter.services.repository.player_store import PlayerStore


# our unit of work
# Step 1. Create a function called acquire_roster() that accepts a team_name and returns a list
# Step 2. Within the function, instantiate a TeamStore().  Use the newly added find_by_name() method
#         to return the team_id.
# Step 3. Instantiate a PlayerStore() object.  Invoke its newly added find_by_team()
#         method to get a list of the associated players.
# Step 4. Return the list of players

