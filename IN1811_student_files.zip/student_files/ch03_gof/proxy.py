class RemoteServer:
    def get_data(self):
        return 'Response from remote server'


class Proxy:
    def __init__(self, remote_server: RemoteServer):
        self.cache = None
        self.remote_server = remote_server

    def get_data(self):
        if self.cache is None:
            self.cache = self.remote_server.get_data()
        else:
            print('Using cache...')
        return self.cache


proxy = Proxy(RemoteServer())
print(proxy.get_data())
print(proxy.get_data())
