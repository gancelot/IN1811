class Singleton:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = object.__new__(cls)
            cls._instance.args = args
            cls._instance.kwargs = kwargs
        return cls._instance

    def __init__(self, value: int = 0):
        self.value = value


s1 = Singleton(10)
print(id(s1))

s2 = Singleton(20)
print(id(s2))

print(s1.value)
