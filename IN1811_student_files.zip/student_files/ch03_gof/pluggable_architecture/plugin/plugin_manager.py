import importlib
import sys
from pathlib import Path

from plugin import Plugin


class PluginNotFound(Exception):
    pass


class PluginManager:
    plugins_dirname = '.plugins'

    def __init__(self, autorun: bool = True):
        """autorun - run plugins immediately automatically"""
        self.plugins_location = Path(__file__).parent / Path(self.plugins_dirname)
        self.plugins_registry = {}
        self.autorun = autorun

    def load_plugins(self) -> None:
        sys.path.append(str(self.plugins_location.resolve()))

        for plugin_file in self.plugins_location.resolve().iterdir():                             # iterate .plugins dir
            if plugin_file.suffix == '.py':
                plugin_module = importlib.import_module(plugin_file.stem, self.plugins_location.name)  # load module
                for name in dir(plugin_module):                                                        # iterate module
                    module_item = getattr(plugin_module, name)                                         # get plugin class
                    try:
                        if issubclass(module_item, Plugin):                                            # is it a Plugin?
                            self.plugins_registry[name] = module_item()                                # instantiate it
                    except TypeError:
                        pass

        if self.autorun:
            self.run_plugins()

    def run_plugins(self) -> None:
        for plugin_name, plugin in self.plugins_registry.items():
            plugin.execute()

    def get_plugin(self, name: str) -> Plugin:
        """name - the class name of the plugin"""
        plugin = self.plugins_registry.get(name)
        if not plugin:
            raise PluginNotFound(name)
        return plugin
