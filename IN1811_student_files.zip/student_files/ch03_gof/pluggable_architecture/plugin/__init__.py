"""
    plugin package

    The plugin package (folder) should be placed in a directory on your sys.path
    (such as lib/sitepackages).
    Plugins will be automatically executed.
    Retrieve them by name using plugin_manager.get('name') where name is the class name of the plugin.
"""
from .plugin import Plugin
from .plugin_manager import PluginManager

plugin_mgr = PluginManager(autorun=False)
plugin_mgr.load_plugins()
