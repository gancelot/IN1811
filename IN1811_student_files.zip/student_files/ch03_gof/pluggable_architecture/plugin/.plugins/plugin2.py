from plugin import Plugin


class Plugin2(Plugin):
    def execute(self):
        print('do stuff within Plugin2')
