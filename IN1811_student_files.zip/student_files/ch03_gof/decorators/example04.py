"""
    example04.py
    Checking for numeric values before calling a function.
"""

from numbers import Number


def check_numeric(some_func):
    def wrapper(*args, **kwargs):
        retval = 'Invalid argument supplied.  Must be numeric.'

        check_args = all(isinstance(arg, Number) for arg in args)
        check_kwargs = all(isinstance(val, Number) for val in kwargs.values())
        if check_args and check_kwargs:
            retval = some_func(*args, **kwargs)

        return retval
    return wrapper


@check_numeric
def sum(x, y):
    return f'Result: {x + y}'


print(sum(10, 3.5))
print(sum(0, 'Johnny'))
