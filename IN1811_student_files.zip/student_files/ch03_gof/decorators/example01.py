"""
    example01.py

"""
def short_formatter(func):
    width = 15

    def wrapper(val):
        val = val[:width] + '...'
        func(val)
    return wrapper


def display(val):
    print(val)


data = 'This is a long string that will be truncated.'

# display = short_formatter(display)                    # run.  uncomment.  run again.

display(data)
