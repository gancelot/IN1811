from abstract_handler import AbstractHandler


class Imputer(AbstractHandler):
    def process(self, data):
        data.append('went through Imputer')
        super().process(data)
