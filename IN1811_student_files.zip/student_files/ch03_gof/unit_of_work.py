"""

    unit_of_work.py

    Demonstrates how to potentially use different data sources that can be managed with a
    unit of work pattern using SQLAlchemy in a single session object.

    At the bottom, two interactions are made with two databases (though, yes, they point to the same url, SQLAlchemy
    handles them as two separate connections).

    There are three possibilities when this runs:
    a) It runs fine (sometimes) and commits.
    b) It errors during the first db interaction and rolls back
    c) It errors during the second db interaction and rolls back

    For ease of reading, all classes have been placed into one module.

"""
from pathlib import Path
from random import randint
from sqlalchemy import create_engine, Integer, String, Column
from sqlalchemy.orm import sessionmaker, Session, declarative_base


# SQLAlchemy classes (we referred to as DTOs previously)
Base = declarative_base()


class TeamStore(Base):
    __tablename__ = 'teams'
    id = Column('id', Integer, primary_key=True)
    common_name = Column(String(40))
    country = Column(String(40))

    def __init__(self, common_name, country):
        super().__init__()
        self.common_name = common_name
        self.country = country

    def __str__(self):
        return self.common_name

    __repr__ = __str__


class PlayerStore(Base):
    __tablename__ = 'players'
    id = Column('id', Integer, primary_key=True, autoincrement=True)
    full_name = Column(String(50))
    age = Column(Integer)
    position = Column(String(40))
    team_id = Column(Integer)

    def __init__(self, full_name, age, position, team):
        super().__init__()
        self.full_name = full_name
        self.age = age
        self.position = position
        self.team = team

    def __str__(self):
        return self.full_name

    __repr__ = __str__


# unit of work using sqlalchemy...
db_url1 = 'sqlite:///' + str(Path(__file__).parents[1] / 'resources/course_data.db')
db_url2 = 'sqlite:///' + str(Path(__file__).parents[1] / 'resources/course_data.db')


class RoutingSession(Session):
    engines = {'team': create_engine(db_url1), 'player': create_engine(db_url2)}

    def get_bind(self, mapper=None, clause=None):
        if mapper and issubclass(mapper.class_, TeamStore):
            return RoutingSession.engines['team']
        else:
            return RoutingSession.engines['player']


class UnitOfWork:
    def __init__(self) -> None:
        self.Session = sessionmaker(class_=RoutingSession)

    def __enter__(self) -> Session:
        self.session = self.Session()
        return self.session

    def __exit__(self, typ, val, tb) -> None:
        if typ:
            self.session.rollback()
            print('Rolling back changes made for this session.')
        else:
            self.session.commit()
            print('Commiting changes made for this session.')
        self.session.close()
        print('Session closed.')


def mock_exception():
    """This will error 50% of the time"""
    if randint(0, 1):
        raise Exception('Random exception occurred.')


# test it out...
try:

    with UnitOfWork() as session:
        print('First db interaction:')
        print(session.query(TeamStore).all())
        mock_exception()

        print('Second db interaction:')
        print(session.query(PlayerStore).all()[:10])
        mock_exception()

except Exception as err:
    print(err)
