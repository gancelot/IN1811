from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import sessionmaker

from ch02_domain.task2_2_starter.repository.base_store import Store, StoreException
from ch02_domain.task2_2_starter.domain.models import Player
from ch02_domain.task2_2_starter.repository.models import PlayerDTO


class PlayerStore(Store):
    db_url = Path(__file__).parents[3] / 'resources/course_data.db'
    db = create_engine('sqlite:///' + str(db_url), echo=True)

    def connect(self):
        try:
            return sessionmaker(bind=PlayerStore.db)()
        except SQLAlchemyError as err:
            raise StoreException('Error getting session.') from err

    # Step 1. Override and complete the add() method.  Pass in a Player object.
    #         The connect() method above is already written.  Use it in a with control to
    #         get a session:
    #                       with self.connect as session:
    #
    #         Within the with control:  a) Transfer data from the Player to the DTO.
    #                                   b) Add the DTO to the session.
    #                                   c) flush() and refresh(dto) the session to get the ID (refer to the notes)
    #                                   d) return the ID


    def get(self, player_id) -> Player:
        pass
        # Step 2. Remove the pass statement.
        # Apply the SQLAlchemy code below and transfer data to the to the DTO.
        # try:
        #     with self.connect() as session:
        #         playerDTO = session.query(PlayerDTO).get(player_id)
        #         player = Player(playerDTO.full_name, playerDTO.age, playerDTO.position, playerDTO.team_id)
        # except Exception as err:
        #     raise StoreException('Error retrieving team.') from err

        # return player