"""

    abstract.py
    Abstract classes in Python

"""
import abc


class Employee(abc.ABC):
    def __init__(self, name):
        self.name = name

    @abc.abstractmethod
    def calc_pay(self):
        pass


class Management(Employee):
    def __init__(self, name, salary):
        super().__init__(name)
        self.salary = salary

    def calc_pay(self):
        return self.salary / 26.0


class HourlyEmployee(Employee):
    def __init__(self, name, rate):
        super().__init__(name)
        self.hours_worked = 0
        self.rate = rate

    def calc_pay(self):
        return self.rate * self.hours_worked


class SlotMachine:
    def __init__(self, input_amount: float):
        self.input_amount = input_amount
        self.rate_usage = 0

    def calc_pay(self):
        return self.rate_usage * self.input_amount


def create_paycheck(emp: Employee):
    return emp.calc_pay()


emp1 = Management('Sally Jones', 85_000)
emp2 = HourlyEmployee('John Smith', 37.50)
emp2.hours_worked = 80
print(f'Manager: {create_paycheck(emp1):.2f}, Hourly Employee: {create_paycheck(emp2):.2f}')

sm = SlotMachine(0.25)
sm.rate_usage = 200
print(f'Works for a slot machine: {create_paycheck(sm)}')

emp3 = Employee('Oscar Bradford')
